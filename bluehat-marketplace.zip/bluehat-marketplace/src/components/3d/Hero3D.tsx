// Bluehat Store - 3D Hero Section Component

import { useRef, useEffect, useState } from 'react';
import { ArrowRight, Sparkles, Zap, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import FloatingCard from './FloatingCard';

export default function Hero3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      
      const rect = containerRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
      const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
      
      setMousePosition({ x: x * 20, y: y * 20 });
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      if (container) {
        container.removeEventListener('mousemove', handleMouseMove);
      }
    };
  }, []);

  const featuredProducts = [
    {
      id: 1,
      name: 'Netflix Premium',
      price: '45.000',
      image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400',
      badge: 'Best Seller',
      color: 'from-red-500 to-pink-500',
    },
    {
      id: 2,
      name: 'Spotify Premium',
      price: '75.000',
      image: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=400',
      badge: 'Populer',
      color: 'from-green-500 to-emerald-500',
    },
    {
      id: 3,
      name: 'Canva Pro',
      price: '150.000',
      image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400',
      badge: 'New',
      color: 'from-blue-500 to-cyan-500',
    },
  ];

  return (
    <section 
      ref={containerRef}
      className="relative min-h-screen flex items-center overflow-hidden pt-20"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Orbs */}
        <div 
          className="absolute top-1/4 -left-32 w-96 h-96 rounded-full opacity-30 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(37,99,235,0.5) 0%, transparent 70%)',
            transform: `translate(${mousePosition.x * 2}px, ${mousePosition.y * 2}px)`,
            transition: 'transform 0.3s ease-out',
          }}
        />
        <div 
          className="absolute bottom-1/4 -right-32 w-96 h-96 rounded-full opacity-30 blur-3xl"
          style={{
            background: 'radial-gradient(circle, rgba(56,189,248,0.5) 0%, transparent 70%)',
            transform: `translate(${-mousePosition.x * 2}px, ${-mousePosition.y * 2}px)`,
            transition: 'transform 0.3s ease-out',
          }}
        />
        
        {/* Grid Pattern */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `
              linear-gradient(rgba(56,189,248,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(56,189,248,0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-cyan-500/30 mb-6">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-cyan-400">
                Marketplace Digital #1 di Indonesia
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              <span className="text-foreground">Beli </span>
              <span className="text-gradient">Produk Digital</span>
              <br />
              <span className="text-foreground">Dengan </span>
              <span className="relative">
                <span className="text-gradient">Mudah</span>
                <svg 
                  className="absolute -bottom-2 left-0 w-full" 
                  viewBox="0 0 200 12" 
                  fill="none"
                >
                  <path 
                    d="M2 10C50 2 150 2 198 10" 
                    stroke="url(#gradient)" 
                    strokeWidth="3" 
                    strokeLinecap="round"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0" y1="0" x2="200" y2="0">
                      <stop stopColor="#2563EB" />
                      <stop offset="1" stopColor="#38BDF8" />
                    </linearGradient>
                  </defs>
                </svg>
              </span>
              <span className="text-foreground"> & </span>
              <span className="text-gradient">Aman</span>
            </h1>

            {/* Description */}
            <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0">
              Dapatkan akses premium ke aplikasi favoritmu dengan harga terbaik. 
              Netflix, Spotify, Canva, dan ratusan produk digital lainnya. 
              Garansi uang kembali 100%!
            </p>

            {/* Features */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-8">
              {[
                { icon: Zap, text: 'Instant Delivery' },
                { icon: Shield, text: 'Garansi 100%' },
                { icon: Sparkles, text: 'Harga Termurah' },
              ].map((feature, index) => (
                <div 
                  key={index}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5"
                >
                  <feature.icon className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm text-foreground">{feature.text}</span>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link to="/products">
                <Button 
                  size="lg"
                  className="bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white px-8 h-14 text-lg group"
                >
                  Jelajahi Produk
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/about">
                <Button 
                  variant="outline"
                  size="lg"
                  className="border-cyan-500/30 hover:bg-cyan-500/10 h-14 text-lg"
                >
                  Pelajari Lebih Lanjut
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mt-12 pt-8 border-t border-cyan-500/20">
              {[
                { value: '50K+', label: 'Pelanggan' },
                { value: '100+', label: 'Produk' },
                { value: '99%', label: 'Puas' },
              ].map((stat, index) => (
                <div key={index} className="text-center lg:text-left">
                  <p className="text-2xl sm:text-3xl font-bold text-gradient">
                    {stat.value}
                  </p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Content - 3D Cards */}
          <div className="relative hidden lg:block">
            <div className="relative h-[500px] perspective-1200">
              {featuredProducts.map((product, index) => {
                const positions = [
                  { x: 0, y: 0, z: 100, rotate: -5 },
                  { x: 180, y: 80, z: 50, rotate: 5 },
                  { x: 80, y: 200, z: 0, rotate: 0 },
                ];
                const pos = positions[index];

                return (
                  <FloatingCard
                    key={product.id}
                    className="absolute"
                    intensity={10}
                  >
                    <div
                      className="w-56 rounded-2xl overflow-hidden glass border border-cyan-500/20 shadow-2xl"
                      style={{
                        transform: `translate3d(${pos.x}px, ${pos.y}px, ${pos.z}px) rotateY(${pos.rotate}deg)`,
                      }}
                    >
                      {/* Image */}
                      <div className="relative h-32 overflow-hidden">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                        <div className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium text-white bg-gradient-to-r ${product.color}`}>
                          {product.badge}
                        </div>
                      </div>

                      {/* Content */}
                      <div className="p-4">
                        <h3 className="font-semibold text-foreground mb-1">
                          {product.name}
                        </h3>
                        <p className="text-lg font-bold text-cyan-400">
                          Rp {product.price}
                        </p>
                      </div>
                    </div>
                  </FloatingCard>
                );
              })}

              {/* Decorative Elements */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-full border border-cyan-500/10 animate-pulse" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full border border-cyan-500/5" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#050B1E] to-transparent" />
    </section>
  );
}
