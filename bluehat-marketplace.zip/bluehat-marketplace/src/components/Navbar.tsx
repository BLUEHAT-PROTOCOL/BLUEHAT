// Bluehat Store - Navbar Component

import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ShoppingCart, Search, User, Menu, X, Heart, 
  Bell, ChevronDown, LogOut, Package
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useCartStore, useAuthStore, useUIStore, useWishlistStore, useNotificationStore } from '@/store/useStore';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  const { getCartCount } = useCartStore();
  const { items: wishlistItems } = useWishlistStore();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { unreadCount } = useNotificationStore();
  const { setCartOpen, setSearchOpen } = useUIStore();

  const cartCount = getCartCount();
  const wishlistCount = wishlistItems.length;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Beranda', href: '/' },
    { label: 'Produk', href: '/products' },
    { label: 'Flash Sale', href: '/products?sale=true' },
    { label: 'Tentang', href: '/about' },
    { label: 'Kontak', href: '/contact' },
  ];

  return (
    <>
      <header 
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
          scrolled 
            ? 'glass-strong border-b border-cyan-500/20' 
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/30 group-hover:shadow-blue-500/50 transition-shadow">
                <span className="text-white font-bold text-xl">B</span>
              </div>
              <div className="hidden sm:block">
                <span className="text-xl font-bold text-gradient block leading-tight">Bluehat</span>
                <span className="text-xs text-muted-foreground tracking-wider">STORE</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all"
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2.5 rounded-lg hover:bg-white/10 transition-colors"
                aria-label="Search"
              >
                <Search className="w-5 h-5 text-muted-foreground" />
              </button>

              {/* Wishlist */}
              <Link
                to="/user/wishlist"
                className="hidden sm:flex p-2.5 rounded-lg hover:bg-white/10 transition-colors relative"
                aria-label="Wishlist"
              >
                <Heart className="w-5 h-5 text-muted-foreground" />
                {wishlistCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-pink-500 to-rose-500 rounded-full text-xs font-medium text-white flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </Link>

              {/* Cart */}
              <button
                onClick={() => setCartOpen(true)}
                className="p-2.5 rounded-lg hover:bg-white/10 transition-colors relative"
                aria-label="Cart"
              >
                <ShoppingCart className="w-5 h-5 text-muted-foreground" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-full text-xs font-medium text-white flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* User Menu */}
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 p-1.5 pl-3 rounded-full hover:bg-white/10 transition-colors ml-2">
                      <span className="hidden md:block text-sm font-medium text-foreground">
                        {user?.name?.split(' ')[0]}
                      </span>
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                        <span className="text-white font-medium text-sm">
                          {user?.name?.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <ChevronDown className="w-4 h-4 text-muted-foreground hidden md:block" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 glass-strong border-cyan-500/20">
                    <div className="px-3 py-2 border-b border-cyan-500/20">
                      <p className="font-medium text-foreground">{user?.name}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    
                    <DropdownMenuItem onClick={() => navigate('/user/dashboard')} className="cursor-pointer">
                      <LayoutDashboard className="w-4 h-4 mr-2" />
                      Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/user/orders')} className="cursor-pointer">
                      <Package className="w-4 h-4 mr-2" />
                      Pesanan Saya
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/user/notifications')} className="cursor-pointer">
                      <Bell className="w-4 h-4 mr-2" />
                      Notifikasi
                      {unreadCount > 0 && (
                        <span className="ml-auto bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                          {unreadCount}
                        </span>
                      )}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/user/profile')} className="cursor-pointer">
                      <User className="w-4 h-4 mr-2" />
                      Profil
                    </DropdownMenuItem>
                    
                    <DropdownMenuSeparator className="bg-cyan-500/20" />
                    
                    {user?.role === 'admin' && (
                      <DropdownMenuItem onClick={() => navigate('/admin/dashboard')} className="cursor-pointer">
                        <LayoutDashboard className="w-4 h-4 mr-2" />
                        Admin Panel
                      </DropdownMenuItem>
                    )}
                    
                    <DropdownMenuItem onClick={logout} className="cursor-pointer text-red-400 focus:text-red-400">
                      <LogOut className="w-4 h-4 mr-2" />
                      Keluar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="hidden sm:flex items-center gap-2 ml-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate('/login')}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    Masuk
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => navigate('/register')}
                    className="bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500"
                  >
                    Daftar
                  </Button>
                </div>
              )}

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2.5 rounded-lg hover:bg-white/10 transition-colors"
                aria-label="Menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div 
        className={cn(
          'fixed inset-0 z-40 lg:hidden transition-all duration-300',
          mobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        )}
      >
        <div 
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
        <div 
          className={cn(
            'absolute top-16 left-0 right-0 glass-strong border-b border-cyan-500/20 transition-transform duration-300',
            mobileMenuOpen ? 'translate-y-0' : '-translate-y-full'
          )}
        >
          <nav className="p-4 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-lg text-foreground hover:bg-white/5 transition-colors"
              >
                {link.label}
              </Link>
            ))}
            
            {!isAuthenticated && (
              <div className="pt-4 mt-4 border-t border-cyan-500/20 space-y-2">
                <Button
                  variant="outline"
                  className="w-full border-cyan-500/30"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navigate('/login');
                  }}
                >
                  Masuk
                </Button>
                <Button
                  className="w-full bg-gradient-to-r from-blue-500 to-cyan-400"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    navigate('/register');
                  }}
                >
                  Daftar
                </Button>
              </div>
            )}
          </nav>
        </div>
      </div>
    </>
  );
}
