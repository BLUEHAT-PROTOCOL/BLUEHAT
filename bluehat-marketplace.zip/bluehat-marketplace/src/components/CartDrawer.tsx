// Bluehat Store - Cart Drawer Component

import { Link } from 'react-router-dom';
import { X, Plus, Minus, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useCartStore } from '@/store/useStore';
import { toast } from 'sonner';

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
}

export default function CartDrawer({ open, onClose }: CartDrawerProps) {
  const { items, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCartStore();
  const total = getCartTotal();

  const handleRemove = (itemId: string, productName: string) => {
    removeFromCart(itemId);
    toast.success(`${productName} dihapus dari keranjang`);
  };

  const handleClear = () => {
    clearCart();
    toast.success('Keranjang dikosongkan');
  };

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg glass-strong border-l border-cyan-500/20 flex flex-col">
        <SheetHeader className="border-b border-cyan-500/20 pb-4">
          <div className="flex items-center justify-between">
            <SheetTitle className="flex items-center gap-2 text-foreground">
              <ShoppingBag className="w-5 h-5 text-cyan-400" />
              Keranjang Belanja
              <span className="text-sm font-normal text-muted-foreground">
                ({items.length} item)
              </span>
            </SheetTitle>
          </div>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mb-6">
              <ShoppingBag className="w-12 h-12 text-cyan-400" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Keranjang Kosong
            </h3>
            <p className="text-muted-foreground mb-6 max-w-xs">
              Belum ada produk di keranjang. Yuk, mulai belanja!
            </p>
            <Button 
              onClick={onClose}
              className="bg-gradient-to-r from-blue-500 to-cyan-400"
            >
              Lihat Produk
            </Button>
          </div>
        ) : (
          <>
            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-4 rounded-xl bg-white/5 border border-cyan-500/10 group hover:border-cyan-500/30 transition-colors"
                >
                  {/* Product Image */}
                  <div className="w-20 h-20 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Product Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <Link
                        to={`/product/${item.product.slug}`}
                        onClick={onClose}
                        className="font-medium text-foreground hover:text-cyan-400 transition-colors line-clamp-1"
                      >
                        {item.product.name}
                      </Link>
                      <button
                        onClick={() => handleRemove(item.id, item.product.name)}
                        className="p-1.5 rounded-lg hover:bg-red-500/10 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="text-sm text-muted-foreground mt-1">
                      {item.product.type === 'physical' ? 'Produk Fisik' : 'Produk Digital'}
                    </p>

                    <div className="flex items-center justify-between mt-3">
                      {/* Quantity Controls */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Price */}
                      <p className="font-semibold text-cyan-400">
                        Rp {(item.product.price * item.quantity).toLocaleString('id-ID')}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-cyan-500/20 pt-4 space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium text-foreground">
                  Rp {total.toLocaleString('id-ID')}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Total</span>
                <span className="text-xl font-bold text-gradient">
                  Rp {total.toLocaleString('id-ID')}
                </span>
              </div>

              <div className="space-y-2">
                <Link to="/checkout" onClick={onClose}>
                  <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 h-12">
                    Checkout
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                
                <Button
                  variant="ghost"
                  onClick={handleClear}
                  className="w-full text-muted-foreground hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Kosongkan Keranjang
                </Button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
