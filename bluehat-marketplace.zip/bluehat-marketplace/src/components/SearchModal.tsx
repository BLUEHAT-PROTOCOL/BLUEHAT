// Bluehat Store - Search Modal Component

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useProductStore } from '@/store/useStore';

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
}

const popularSearches = [
  'Netflix Premium',
  'Spotify',
  'Canva Pro',
  'Windows 11',
  'Steam Wallet',
];

const recentSearches: string[] = [];

export default function SearchModal({ open, onClose }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ReturnType<typeof useProductStore.getState>['products']>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  
  const { products, searchProducts } = useProductStore();

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  useEffect(() => {
    if (query.trim()) {
      const searchResults = searchProducts(query);
      setResults(searchResults.slice(0, 6));
    } else {
      setResults([]);
    }
  }, [query, searchProducts]);

  const handleSearch = (searchQuery: string) => {
    if (searchQuery.trim()) {
      onClose();
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch(query);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 glass-strong border border-cyan-500/20 overflow-hidden">
        {/* Search Input */}
        <div className="flex items-center gap-4 p-4 border-b border-cyan-500/20">
          <Search className="w-5 h-5 text-cyan-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Cari produk..."
            className="flex-1 bg-transparent border-none outline-none text-foreground placeholder:text-muted-foreground text-lg"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          )}
        </div>

        {/* Search Results or Suggestions */}
        <div className="max-h-[60vh] overflow-y-auto">
          {query.trim() ? (
            // Search Results
            results.length > 0 ? (
              <div className="p-2">
                <p className="px-4 py-2 text-xs font-medium text-muted-foreground uppercase">
                  Hasil Pencarian
                </p>
                {results.map((product) => (
                  <button
                    key={product.id}
                    onClick={() => {
                      onClose();
                      navigate(`/product/${product.slug}`);
                    }}
                    className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-white/5 transition-colors text-left"
                  >
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {product.name}
                      </p>
                      <p className="text-sm text-cyan-400">
                        Rp {product.price.toLocaleString('id-ID')}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                  </button>
                ))}
                <button
                  onClick={() => handleSearch(query)}
                  className="w-full flex items-center justify-center gap-2 p-3 mt-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors text-cyan-400"
                >
                  <span>Lihat semua hasil untuk "{query}"</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="p-8 text-center">
                <p className="text-muted-foreground">
                  Tidak ada hasil untuk "{query}"
                </p>
              </div>
            )
          ) : (
            // Suggestions
            <div className="p-2">
              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <>
                  <p className="px-4 py-2 text-xs font-medium text-muted-foreground uppercase">
                    Pencarian Terakhir
                  </p>
                  {recentSearches.map((search, index) => (
                    <button
                      key={index}
                      onClick={() => handleSearch(search)}
                      className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span className="text-foreground">{search}</span>
                    </button>
                  ))}
                </>
              )}

              {/* Popular Searches */}
              <p className="px-4 py-2 text-xs font-medium text-muted-foreground uppercase">
                Pencarian Populer
              </p>
              {popularSearches.map((search, index) => (
                <button
                  key={index}
                  onClick={() => handleSearch(search)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  <span className="text-foreground">{search}</span>
                </button>
              ))}

              {/* Quick Categories */}
              <p className="px-4 py-2 mt-4 text-xs font-medium text-muted-foreground uppercase">
                Kategori Populer
              </p>
              <div className="flex flex-wrap gap-2 p-3">
                {['Apps Premium', 'Kode Redeem', 'Digital Assets', 'License Key'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => handleSearch(cat)}
                    className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-cyan-500/20 text-sm text-foreground transition-colors"
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
