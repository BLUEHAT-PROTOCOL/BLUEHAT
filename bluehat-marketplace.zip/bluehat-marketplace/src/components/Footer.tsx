// Bluehat Store - Footer Component

import { Link } from 'react-router-dom';
import { 
  Mail, Phone, MapPin, Facebook, Twitter, Instagram, 
  Youtube, CreditCard, Shield, Truck, Headphones
} from 'lucide-react';

const footerLinks = {
  shop: [
    { label: 'Semua Produk', href: '/products' },
    { label: 'Apps Premium', href: '/products?category=apps-premium' },
    { label: 'Kode Redeem', href: '/products?category=kode-redeem' },
    { label: 'Digital Assets', href: '/products?category=digital-assets' },
    { label: 'Flash Sale', href: '/products?sale=true' },
  ],
  support: [
    { label: 'Pusat Bantuan', href: '/faq' },
    { label: 'Cara Pembelian', href: '/faq' },
    { label: 'Konfirmasi Pembayaran', href: '/payment-confirm' },
    { label: 'Lacak Pesanan', href: '/user/orders' },
    { label: 'Hubungi Kami', href: '/contact' },
  ],
  company: [
    { label: 'Tentang Kami', href: '/about' },
    { label: 'Kebijakan Privasi', href: '/privacy' },
    { label: 'Syarat & Ketentuan', href: '/terms' },
    { label: 'Karir', href: '/careers' },
  ],
};

const paymentMethods = [
  { name: 'QRIS', logo: 'QRIS' },
  { name: 'DANA', logo: 'DANA' },
  { name: 'GoPay', logo: 'GoPay' },
  { name: 'OVO', logo: 'OVO' },
  { name: 'BCA', logo: 'BCA' },
  { name: 'Mandiri', logo: 'Mandiri' },
];

const features = [
  { icon: Shield, title: 'Garansi 100%', desc: 'Uang kembali' },
  { icon: Truck, title: 'Instant Delivery', desc: 'Produk digital' },
  { icon: Headphones, title: 'Support 24/7', desc: 'Selalu siap' },
  { icon: CreditCard, title: 'Pembayaran Aman', desc: 'Terenkripsi' },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden">
      {/* Features Bar */}
      <div className="border-y border-cyan-500/10 bg-[#0B122F]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-cyan-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{feature.title}</p>
                    <p className="text-sm text-muted-foreground">{feature.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="bg-[#050B1E] pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
            {/* Brand */}
            <div className="lg:col-span-2">
              <Link to="/" className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/30">
                  <span className="text-white font-bold text-xl">B</span>
                </div>
                <div>
                  <span className="text-2xl font-bold text-gradient block leading-tight">Bluehat</span>
                  <span className="text-sm text-muted-foreground tracking-wider">STORE</span>
                </div>
              </Link>
              
              <p className="text-muted-foreground mb-6 max-w-sm">
                Marketplace digital terpercaya untuk kebutuhan aplikasi premium, 
                kode redeem, dan produk digital lainnya. Garansi uang kembali.
              </p>

              <div className="space-y-3">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Mail className="w-5 h-5 text-cyan-400" />
                  <span>support@bluehat.store</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Phone className="w-5 h-5 text-cyan-400" />
                  <span>+62 812-3456-7890</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <MapPin className="w-5 h-5 text-cyan-400" />
                  <span>Jakarta, Indonesia</span>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex items-center gap-3 mt-6">
                {[Facebook, Twitter, Instagram, Youtube].map((Icon, index) => (
                  <a
                    key={index}
                    href="#"
                    className="w-10 h-10 rounded-lg bg-white/5 hover:bg-gradient-to-br hover:from-blue-500 hover:to-cyan-400 flex items-center justify-center transition-all group"
                  >
                    <Icon className="w-5 h-5 text-muted-foreground group-hover:text-white transition-colors" />
                  </a>
                ))}
              </div>
            </div>

            {/* Links */}
            <div>
              <h3 className="font-semibold text-foreground mb-4">Belanja</h3>
              <ul className="space-y-3">
                {footerLinks.shop.map((link) => (
                  <li key={link.href}>
                    <Link 
                      to={link.href}
                      className="text-muted-foreground hover:text-cyan-400 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Bantuan</h3>
              <ul className="space-y-3">
                {footerLinks.support.map((link) => (
                  <li key={link.href}>
                    <Link 
                      to={link.href}
                      className="text-muted-foreground hover:text-cyan-400 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-foreground mb-4">Perusahaan</h3>
              <ul className="space-y-3">
                {footerLinks.company.map((link) => (
                  <li key={link.href}>
                    <Link 
                      to={link.href}
                      className="text-muted-foreground hover:text-cyan-400 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="border-t border-cyan-500/10 pt-8 mb-8">
            <p className="text-sm text-muted-foreground mb-4">Metode Pembayaran:</p>
            <div className="flex flex-wrap items-center gap-4">
              {paymentMethods.map((method) => (
                <div
                  key={method.name}
                  className="px-4 py-2 rounded-lg bg-white/5 border border-cyan-500/10 text-sm font-medium text-muted-foreground"
                >
                  {method.logo}
                </div>
              ))}
            </div>
          </div>

          {/* Copyright */}
          <div className="border-t border-cyan-500/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} Bluehat Store. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <Link to="/privacy" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">
                Kebijakan Privasi
              </Link>
              <Link to="/terms" className="text-sm text-muted-foreground hover:text-cyan-400 transition-colors">
                Syarat & Ketentuan
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
