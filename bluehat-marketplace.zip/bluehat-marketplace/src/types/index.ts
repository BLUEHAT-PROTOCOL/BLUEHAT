// Bluehat Store - Type Definitions

export type ProductType = 'physical' | 'apps_premium' | 'redeem_code' | 'digital_file' | 'membership' | 'license_key';

export type OrderStatus = 'pending' | 'waiting_confirmation' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';

export type PaymentStatus = 'pending' | 'waiting_confirmation' | 'confirmed' | 'rejected' | 'expired' | 'refunded';

export type PaymentMethod = 'qris' | 'dana' | 'gopay' | 'ovo' | 'linkaja' | 'bca' | 'mandiri' | 'bni' | 'bri';

export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  phone?: string;
  role: 'customer' | 'admin' | 'staff';
  createdAt: Date;
  updatedAt: Date;
  loyaltyPoints: number;
  referralCode: string;
  referredBy?: string;
  isVerified: boolean;
  membershipType?: 'free' | 'silver' | 'gold' | 'platinum';
  membershipExpiry?: Date;
}

export interface Address {
  id: string;
  userId: string;
  label: string;
  recipientName: string;
  phone: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  isDefault: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  image?: string;
  parentId?: string;
  order: number;
  isActive: boolean;
}

export interface ProductVariant {
  id: string;
  name: string;
  options: {
    id: string;
    value: string;
    priceAdjustment: number;
    stock: number;
  }[];
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription?: string;
  type: ProductType;
  categoryId: string;
  category?: Category;
  price: number;
  compareAtPrice?: number;
  costPrice?: number;
  stock: number;
  stockAlert: number;
  sku: string;
  barcode?: string;
  weight: number;
  images: string[];
  videos?: string[];
  variants?: ProductVariant[];
  attributes?: Record<string, string>;
  tags: string[];
  isActive: boolean;
  isFeatured: boolean;
  isNewArrival: boolean;
  isBestSeller: boolean;
  isPreOrder: boolean;
  preOrderDays?: number;
  rating: number;
  reviewCount: number;
  viewCount: number;
  salesCount: number;
  createdAt: Date;
  updatedAt: Date;
  seoTitle?: string;
  seoDescription?: string;
  // Digital product specific
  autoDelivery?: boolean;
  deliveryContent?: string;
  fileUrl?: string;
  downloadLimit?: number;
  expiryHours?: number;
  // For apps premium
  stockAccounts?: PremiumAccount[];
  // For redeem codes
  stockCodes?: string[];
  // For license keys
  licensePrefix?: string;
}

export interface PremiumAccount {
  id: string;
  email: string;
  password: string;
  profileName?: string;
  duration: number;
  expiryDate: Date;
  isUsed: boolean;
  usedBy?: string;
  usedAt?: Date;
}

export interface CartItem {
  id: string;
  userId?: string;
  sessionId?: string;
  productId: string;
  product: Product;
  quantity: number;
  variantData?: Record<string, string>;
  addedAt: Date;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  product: Product;
  quantity: number;
  price: number;
  variantData?: Record<string, string>;
  subtotal: number;
  // Digital delivery
  deliveredContent?: string;
  downloadUrl?: string;
  downloadExpiry?: Date;
  downloadCount: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  user?: User;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentMethod;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shippingCost: number;
  tax: number;
  total: number;
  couponCode?: string;
  couponDiscount?: number;
  shippingAddress?: Address;
  billingAddress?: Address;
  notes?: string;
  giftWrap: boolean;
  giftMessage?: string;
  trackingNumber?: string;
  shippingProvider?: string;
  estimatedDelivery?: Date;
  createdAt: Date;
  updatedAt: Date;
  paidAt?: Date;
  confirmedAt?: Date;
  shippedAt?: Date;
  deliveredAt?: Date;
  cancelledAt?: Date;
  cancelReason?: string;
  internalNotes?: string;
  tags: string[];
}

export interface PaymentProof {
  id: string;
  orderId: string;
  order?: Order;
  userId: string;
  imageUrl: string;
  senderName: string;
  senderAccount?: string;
  transferDate: Date;
  transferAmount: number;
  notes?: string;
  status: 'pending' | 'confirmed' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: Date;
  rejectionReason?: string;
  createdAt: Date;
}

export interface Review {
  id: string;
  productId: string;
  product?: Product;
  userId: string;
  user?: User;
  orderId: string;
  rating: number;
  title?: string;
  content: string;
  images?: string[];
  isVerified: boolean;
  isApproved: boolean;
  helpfulCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Coupon {
  id: string;
  code: string;
  description?: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrderAmount?: number;
  maxDiscount?: number;
  usageLimit?: number;
  usageCount: number;
  userLimit?: number;
  startDate: Date;
  endDate: Date;
  isActive: boolean;
  applicableProducts?: string[];
  applicableCategories?: string[];
  excludedProducts?: string[];
}

export interface WishlistItem {
  id: string;
  userId: string;
  productId: string;
  product: Product;
  addedAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'order' | 'payment' | 'shipment' | 'promo' | 'system';
  title: string;
  message: string;
  data?: Record<string, any>;
  isRead: boolean;
  createdAt: Date;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderType: 'customer' | 'admin' | 'system';
  message: string;
  attachments?: string[];
  isRead: boolean;
  createdAt: Date;
}

export interface Chat {
  id: string;
  userId: string;
  user?: User;
  subject?: string;
  status: 'open' | 'closed';
  priority: 'low' | 'medium' | 'high';
  assignedTo?: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Webhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  isActive: boolean;
  secret?: string;
  createdAt: Date;
  lastTriggeredAt?: Date;
  lastResponseStatus?: number;
}

export interface AnalyticsData {
  date: string;
  sales: number;
  orders: number;
  visitors: number;
  conversionRate: number;
  averageOrderValue: number;
}

export interface DashboardStats {
  totalSales: number;
  totalOrders: number;
  totalCustomers: number;
  totalProducts: number;
  pendingOrders: number;
  pendingPayments: number;
  lowStockProducts: number;
  todaySales: number;
  todayOrders: number;
  salesChange: number;
  ordersChange: number;
}
