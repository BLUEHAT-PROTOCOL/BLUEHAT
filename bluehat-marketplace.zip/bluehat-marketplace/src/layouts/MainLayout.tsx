// Bluehat Store - Main Layout

import { Outlet } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import SearchModal from '@/components/SearchModal';
import { useUIStore } from '@/store/useStore';

export default function MainLayout() {
  const { isCartOpen, isSearchOpen, setCartOpen, setSearchOpen } = useUIStore();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#050B1E] to-[#0B122F]">
      <Navbar />
      
      <main className="relative">
        <Outlet />
      </main>
      
      <Footer />
      
      {/* Global Drawers & Modals */}
      <CartDrawer open={isCartOpen} onClose={() => setCartOpen(false)} />
      <SearchModal open={isSearchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}
