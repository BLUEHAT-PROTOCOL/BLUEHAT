// Bluehat Store - User Layout

import { Outlet } from 'react-router-dom';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, ShoppingBag, User, MapPin, Heart, 
  Bell, Ticket, ChevronRight 
} from 'lucide-react';
import { cn } from '@/lib/utils';

const userNavItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '/user/dashboard' },
  { icon: ShoppingBag, label: 'Pesanan Saya', href: '/user/orders' },
  { icon: Heart, label: 'Wishlist', href: '/user/wishlist' },
  { icon: Ticket, label: 'Kupon', href: '/user/coupons' },
  { icon: Bell, label: 'Notifikasi', href: '/user/notifications' },
  { icon: User, label: 'Profil', href: '/user/profile' },
  { icon: MapPin, label: 'Alamat', href: '/user/addresses' },
];

export default function UserLayout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#050B1E] to-[#0B122F]">
      {/* Header */}
      <header className="sticky top-0 z-40 glass border-b border-cyan-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="text-xl font-bold text-gradient">Bluehat Store</span>
          </Link>
          <ChevronRight className="w-5 h-5 text-muted-foreground mx-2" />
          <span className="text-foreground">Akun Saya</span>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <nav className="glass rounded-xl p-4 space-y-1">
              {userNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                
                return (
                  <Link
                    key={item.href}
                    to={item.href}
                    className={cn(
                      'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                      isActive 
                        ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-400 border border-cyan-500/30' 
                        : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                    {isActive && <ChevronRight className="w-4 h-4 ml-auto" />}
                  </Link>
                );
              })}
            </nav>
          </aside>

          {/* Content */}
          <main className="lg:col-span-3">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}
