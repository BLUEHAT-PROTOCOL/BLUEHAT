// Bluehat Store - Zustand Store

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  User, Product, CartItem, WishlistItem, 
  Order, Notification, Category 
} from '@/types';
import { 
  products as mockProducts, 
  categories as mockCategories,
  cartItems as mockCartItems,
  wishlistItems as mockWishlistItems,
  orders as mockOrders,
  notifications as mockNotifications,
  currentUser as mockUser 
} from '@/data/mockData';

// Cart Store
interface CartStore {
  items: CartItem[];
  addToCart: (product: Product, quantity: number, variantData?: Record<string, string>) => void;
  removeFromCart: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: mockCartItems,
      
      addToCart: (product, quantity, variantData) => {
        const { items } = get();
        const existingItem = items.find(item => 
          item.productId === product.id && 
          JSON.stringify(item.variantData) === JSON.stringify(variantData)
        );
        
        if (existingItem) {
          set({
            items: items.map(item =>
              item.id === existingItem.id
                ? { ...item, quantity: item.quantity + quantity }
                : item
            ),
          });
        } else {
          const newItem: CartItem = {
            id: `cart-${Date.now()}`,
            productId: product.id,
            product,
            quantity,
            variantData,
            addedAt: new Date(),
          };
          set({ items: [...items, newItem] });
        }
      },
      
      removeFromCart: (itemId) => {
        set({ items: get().items.filter(item => item.id !== itemId) });
      },
      
      updateQuantity: (itemId, quantity) => {
        if (quantity <= 0) {
          get().removeFromCart(itemId);
          return;
        }
        set({
          items: get().items.map(item =>
            item.id === itemId ? { ...item, quantity } : item
          ),
        });
      },
      
      clearCart: () => set({ items: [] }),
      
      getCartTotal: () => {
        return get().items.reduce((total, item) => {
          return total + (item.product.price * item.quantity);
        }, 0);
      },
      
      getCartCount: () => {
        return get().items.reduce((count, item) => count + item.quantity, 0);
      },
    }),
    {
      name: 'bluehat-cart',
    }
  )
);

// Wishlist Store
interface WishlistStore {
  items: WishlistItem[];
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  toggleWishlist: (product: Product) => void;
}

export const useWishlistStore = create<WishlistStore>()(
  persist(
    (set, get) => ({
      items: mockWishlistItems,
      
      addToWishlist: (product) => {
        const { items } = get();
        if (!items.find(item => item.productId === product.id)) {
          const newItem: WishlistItem = {
            id: `wish-${Date.now()}`,
            productId: product.id,
            product,
            addedAt: new Date(),
          };
          set({ items: [...items, newItem] });
        }
      },
      
      removeFromWishlist: (productId) => {
        set({ items: get().items.filter(item => item.productId !== productId) });
      },
      
      isInWishlist: (productId) => {
        return get().items.some(item => item.productId === productId);
      },
      
      toggleWishlist: (product) => {
        const { isInWishlist, addToWishlist, removeFromWishlist } = get();
        if (isInWishlist(product.id)) {
          removeFromWishlist(product.id);
        } else {
          addToWishlist(product);
        }
      },
    }),
    {
      name: 'bluehat-wishlist',
    }
  )
);

// Auth Store
interface AuthStore {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: mockUser,
      isAuthenticated: true,
      isAdmin: false,
      
      login: (user) => set({ 
        user, 
        isAuthenticated: true, 
        isAdmin: user.role === 'admin' 
      }),
      
      logout: () => set({ 
        user: null, 
        isAuthenticated: false, 
        isAdmin: false 
      }),
      
      updateUser: (userData) => set((state) => ({
        user: state.user ? { ...state.user, ...userData } : null,
      })),
    }),
    {
      name: 'bluehat-auth',
    }
  )
);

// Product Store
interface ProductStore {
  products: Product[];
  categories: Category[];
  featuredProducts: Product[];
  newArrivals: Product[];
  bestSellers: Product[];
  getProductBySlug: (slug: string) => Product | undefined;
  getProductsByCategory: (categoryId: string) => Product[];
  searchProducts: (query: string) => Product[];
}

export const useProductStore = create<ProductStore>()((set, get) => ({
  products: mockProducts,
  categories: mockCategories,
  featuredProducts: mockProducts.filter(p => p.isFeatured),
  newArrivals: mockProducts.filter(p => p.isNewArrival),
  bestSellers: mockProducts.filter(p => p.isBestSeller),
  
  getProductBySlug: (slug) => {
    return get().products.find(p => p.slug === slug);
  },
  
  getProductsByCategory: (categoryId) => {
    return get().products.filter(p => p.categoryId === categoryId);
  },
  
  searchProducts: (query) => {
    const lowerQuery = query.toLowerCase();
    return get().products.filter(p =>
      p.name.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery) ||
      p.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
    );
  },
}));

// Order Store
interface OrderStore {
  orders: Order[];
  addOrder: (order: Order) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  updatePaymentStatus: (orderId: string, status: Order['paymentStatus']) => void;
  getOrderById: (orderId: string) => Order | undefined;
  getUserOrders: (userId: string) => Order[];
}

export const useOrderStore = create<OrderStore>()((set, get) => ({
  orders: mockOrders,
  
  addOrder: (order) => {
    set({ orders: [order, ...get().orders] });
  },
  
  updateOrderStatus: (orderId, status) => {
    set({
      orders: get().orders.map(order =>
        order.id === orderId ? { ...order, status, updatedAt: new Date() } : order
      ),
    });
  },
  
  updatePaymentStatus: (orderId, status) => {
    set({
      orders: get().orders.map(order =>
        order.id === orderId ? { ...order, paymentStatus: status, updatedAt: new Date() } : order
      ),
    });
  },
  
  getOrderById: (orderId) => {
    return get().orders.find(o => o.id === orderId);
  },
  
  getUserOrders: (userId) => {
    return get().orders.filter(o => o.userId === userId);
  },
}));

// Notification Store
interface NotificationStore {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Notification) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  clearNotifications: () => void;
}

export const useNotificationStore = create<NotificationStore>()((set, get) => ({
  notifications: mockNotifications,
  unreadCount: mockNotifications.filter(n => !n.isRead).length,
  
  addNotification: (notification) => {
    set({ 
      notifications: [notification, ...get().notifications],
      unreadCount: get().unreadCount + 1,
    });
  },
  
  markAsRead: (notificationId) => {
    set({
      notifications: get().notifications.map(n =>
        n.id === notificationId ? { ...n, isRead: true } : n
      ),
      unreadCount: Math.max(0, get().unreadCount - 1),
    });
  },
  
  markAllAsRead: () => {
    set({
      notifications: get().notifications.map(n => ({ ...n, isRead: true })),
      unreadCount: 0,
    });
  },
  
  clearNotifications: () => {
    set({ notifications: [], unreadCount: 0 });
  },
}));

// UI Store
interface UIStore {
  isSidebarOpen: boolean;
  isCartOpen: boolean;
  isSearchOpen: boolean;
  isMobileMenuOpen: boolean;
  toggleSidebar: () => void;
  toggleCart: () => void;
  toggleSearch: () => void;
  toggleMobileMenu: () => void;
  setSidebarOpen: (open: boolean) => void;
  setCartOpen: (open: boolean) => void;
  setSearchOpen: (open: boolean) => void;
  setMobileMenuOpen: (open: boolean) => void;
}

export const useUIStore = create<UIStore>()((set) => ({
  isSidebarOpen: false,
  isCartOpen: false,
  isSearchOpen: false,
  isMobileMenuOpen: false,
  
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  toggleCart: () => set((state) => ({ isCartOpen: !state.isCartOpen })),
  toggleSearch: () => set((state) => ({ isSearchOpen: !state.isSearchOpen })),
  toggleMobileMenu: () => set((state) => ({ isMobileMenuOpen: !state.isMobileMenuOpen })),
  
  setSidebarOpen: (open) => set({ isSidebarOpen: open }),
  setCartOpen: (open) => set({ isCartOpen: open }),
  setSearchOpen: (open) => set({ isSearchOpen: open }),
  setMobileMenuOpen: (open) => set({ isMobileMenuOpen: open }),
}));
