// Bluehat Store - Main App Component

import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';

// Layouts
import MainLayout from '@/layouts/MainLayout';
import AdminLayout from '@/layouts/AdminLayout';
import UserLayout from '@/layouts/UserLayout';

// Pages
import HomePage from '@/pages/HomePage';
import ProductsPage from '@/pages/ProductsPage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import CartPage from '@/pages/CartPage';
import CheckoutPage from '@/pages/CheckoutPage';
import PaymentConfirmPage from '@/pages/PaymentConfirmPage';
import PaymentStatusPage from '@/pages/PaymentStatusPage';
import OrderSuccessPage from '@/pages/OrderSuccessPage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import FAQPage from '@/pages/FAQPage';

// User Pages
import UserDashboard from '@/pages/user/Dashboard';
import UserOrders from '@/pages/user/Orders';
import UserOrderDetail from '@/pages/user/OrderDetail';
import UserProfile from '@/pages/user/Profile';
import UserAddresses from '@/pages/user/Addresses';
import UserWishlist from '@/pages/user/Wishlist';
import UserNotifications from '@/pages/user/Notifications';
import UserCoupons from '@/pages/user/Coupons';

// Admin Pages
import AdminDashboard from '@/pages/admin/Dashboard';
import AdminProducts from '@/pages/admin/Products';
import AdminProductEdit from '@/pages/admin/ProductEdit';
import AdminOrders from '@/pages/admin/Orders';
import AdminOrderDetail from '@/pages/admin/OrderDetail';
import AdminPayments from '@/pages/admin/Payments';
import AdminCustomers from '@/pages/admin/Customers';
import AdminAnalytics from '@/pages/admin/Analytics';
import AdminCoupons from '@/pages/admin/Coupons';
import AdminSettings from '@/pages/admin/Settings';

// Hooks
import { useAuthStore } from '@/store/useStore';

// Protected Route Component
const ProtectedRoute = ({ children, requireAdmin = false }: { children: React.ReactNode; requireAdmin?: boolean }) => {
  const { isAuthenticated, isAdmin } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (requireAdmin && !isAdmin) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  useEffect(() => {
    // Smooth scroll polyfill for older browsers
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <TooltipProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route element={<MainLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/products" element={<ProductsPage />} />
            <Route path="/product/:slug" element={<ProductDetailPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FAQPage />} />
          </Route>
          
          {/* Auth Routes */}
          <Route element={<MainLayout />}>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
          </Route>
          
          {/* Checkout Routes */}
          <Route element={<MainLayout />}>
            <Route 
              path="/checkout" 
              element={
                <ProtectedRoute>
                  <CheckoutPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/payment-confirm/:orderId" 
              element={
                <ProtectedRoute>
                  <PaymentConfirmPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/payment-status/:orderId" 
              element={
                <ProtectedRoute>
                  <PaymentStatusPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/order-success/:orderId" 
              element={
                <ProtectedRoute>
                  <OrderSuccessPage />
                </ProtectedRoute>
              } 
            />
          </Route>
          
          {/* User Routes */}
          <Route 
            element={
              <ProtectedRoute>
                <UserLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/user/dashboard" element={<UserDashboard />} />
            <Route path="/user/orders" element={<UserOrders />} />
            <Route path="/user/orders/:orderId" element={<UserOrderDetail />} />
            <Route path="/user/profile" element={<UserProfile />} />
            <Route path="/user/addresses" element={<UserAddresses />} />
            <Route path="/user/wishlist" element={<UserWishlist />} />
            <Route path="/user/notifications" element={<UserNotifications />} />
            <Route path="/user/coupons" element={<UserCoupons />} />
          </Route>
          
          {/* Admin Routes */}
          <Route 
            element={
              <ProtectedRoute requireAdmin>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/products" element={<AdminProducts />} />
            <Route path="/admin/products/add" element={<AdminProductEdit />} />
            <Route path="/admin/products/edit/:id" element={<AdminProductEdit />} />
            <Route path="/admin/orders" element={<AdminOrders />} />
            <Route path="/admin/orders/:orderId" element={<AdminOrderDetail />} />
            <Route path="/admin/payments" element={<AdminPayments />} />
            <Route path="/admin/customers" element={<AdminCustomers />} />
            <Route path="/admin/analytics" element={<AdminAnalytics />} />
            <Route path="/admin/coupons" element={<AdminCoupons />} />
            <Route path="/admin/settings" element={<AdminSettings />} />
          </Route>
          
          {/* 404 Redirect */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      
      <Toaster 
        position="top-right"
        toastOptions={{
          style: {
            background: '#0B122F',
            border: '1px solid rgba(56, 189, 248, 0.25)',
            color: '#EAF2FF',
          },
        }}
      />
    </TooltipProvider>
  );
}

export default App;
