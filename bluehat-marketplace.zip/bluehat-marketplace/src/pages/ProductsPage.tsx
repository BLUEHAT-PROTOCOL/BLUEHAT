// Bluehat Store - Products Page

import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { 
  Search, Filter, Grid3X3, List, Star, ArrowRight,
  ChevronDown, X, SlidersHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Checkbox } from '@/components/ui/checkbox';
import { useProductStore } from '@/store/useStore';
import { cn } from '@/lib/utils';

// Product Card Component
function ProductCard({ product, viewMode }: { product: ReturnType<typeof useProductStore.getState>['products'][0]; viewMode: 'grid' | 'list' }) {
  const getProductTypeBadge = (type: string) => {
    switch (type) {
      case 'apps_premium':
        return { label: 'AUTO ACCOUNT', className: 'badge-apps' };
      case 'redeem_code':
        return { label: 'INSTANT CODE', className: 'badge-redeem' };
      case 'digital_file':
        return { label: 'DIGITAL DOWNLOAD', className: 'badge-digital' };
      case 'membership':
        return { label: 'SUBSCRIPTION', className: 'badge-membership' };
      case 'license_key':
        return { label: 'LICENSE', className: 'badge-license' };
      default:
        return { label: 'PHYSICAL', className: 'bg-gray-500 text-white' };
    }
  };

  const badge = getProductTypeBadge(product.type);

  if (viewMode === 'list') {
    return (
      <Link to={`/product/${product.slug}`}>
        <Card className="group glass border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300">
          <div className="flex gap-4 p-4">
            <div className="w-32 h-32 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <Badge className={`${badge.className} text-xs mb-2`}>
                    {badge.label}
                  </Badge>
                  <h3 className="font-semibold text-foreground group-hover:text-cyan-400 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {product.description}
                  </p>
                </div>
                
                <div className="text-right flex-shrink-0">
                  <p className="text-xl font-bold text-cyan-400">
                    Rp {product.price.toLocaleString('id-ID')}
                  </p>
                  {product.compareAtPrice && (
                    <p className="text-sm text-muted-foreground line-through">
                      Rp {product.compareAtPrice.toLocaleString('id-ID')}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm text-foreground">{product.rating}</span>
                    <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {product.salesCount} terjual
                  </span>
                </div>
                
                <Button size="sm" className="bg-gradient-to-r from-blue-500 to-cyan-400">
                  Lihat Detail
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </Link>
    );
  }

  return (
    <Link to={`/product/${product.slug}`}>
      <Card className="group glass border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300 overflow-hidden h-full flex flex-col">
        <div className="relative aspect-square overflow-hidden">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            <Badge className={`${badge.className} text-xs`}>
              {badge.label}
            </Badge>
            {product.isNewArrival && (
              <Badge className="bg-green-500 text-white text-xs">NEW</Badge>
            )}
            {product.compareAtPrice && (
              <Badge className="bg-red-500 text-white text-xs">
                -{Math.round((1 - product.price / product.compareAtPrice) * 100)}%
              </Badge>
            )}
          </div>
        </div>

        <CardContent className="p-4 flex-1 flex flex-col">
          <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-cyan-400 transition-colors">
            {product.name}
          </h3>
          
          <p className="text-sm text-muted-foreground line-clamp-1 mt-1">
            {product.shortDescription}
          </p>

          <div className="flex items-center gap-1 mt-2">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-foreground">{product.rating}</span>
            <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
          </div>

          <div className="flex items-center justify-between mt-auto pt-3">
            <div>
              <p className="text-lg font-bold text-cyan-400">
                Rp {product.price.toLocaleString('id-ID')}
              </p>
              {product.compareAtPrice && (
                <p className="text-sm text-muted-foreground line-through">
                  Rp {product.compareAtPrice.toLocaleString('id-ID')}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { products, categories } = useProductStore();
  
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000000]);
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let result = [...products];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Category filter
    if (selectedCategory) {
      const category = categories.find(c => c.slug === selectedCategory);
      if (category) {
        result = result.filter(p => p.categoryId === category.id);
      }
    }

    // Price filter
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    // Sort
    switch (sortBy) {
      case 'price_low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price_high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'best_seller':
        result.sort((a, b) => b.salesCount - a.salesCount);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
    }

    return result;
  }, [products, searchQuery, selectedCategory, priceRange, sortBy, categories]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(searchParams);
    if (searchQuery) {
      params.set('search', searchQuery);
    } else {
      params.delete('search');
    }
    setSearchParams(params);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setPriceRange([0, 1000000]);
    setSearchParams(new URLSearchParams());
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Semua <span className="text-gradient">Produk</span>
          </h1>
          
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <form onSubmit={handleSearch} className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Cari produk..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/5 border-cyan-500/20"
                />
              </div>
            </form>
            
            <div className="flex gap-2">
              {/* Mobile Filter Button */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden border-cyan-500/30">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="glass-strong border-r border-cyan-500/20">
                  <SheetHeader>
                    <SheetTitle>Filter Produk</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    {/* Categories */}
                    <div>
                      <h4 className="font-medium mb-3">Kategori</h4>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <label key={category.id} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox
                              checked={selectedCategory === category.slug}
                              onCheckedChange={() => setSelectedCategory(
                                selectedCategory === category.slug ? '' : category.slug
                              )}
                            />
                            <span className="text-sm">{category.name}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>

              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px] bg-white/5 border-cyan-500/20">
                  <SelectValue placeholder="Urutkan" />
                </SelectTrigger>
                <SelectContent className="glass-strong border-cyan-500/20">
                  <SelectItem value="featured">Unggulan</SelectItem>
                  <SelectItem value="price_low">Harga: Rendah ke Tinggi</SelectItem>
                  <SelectItem value="price_high">Harga: Tinggi ke Rendah</SelectItem>
                  <SelectItem value="newest">Terbaru</SelectItem>
                  <SelectItem value="best_seller">Terlaris</SelectItem>
                  <SelectItem value="rating">Rating Tertinggi</SelectItem>
                </SelectContent>
              </Select>

              {/* View Mode */}
              <div className="hidden sm:flex border border-cyan-500/20 rounded-lg overflow-hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  className={cn(
                    'p-2 transition-colors',
                    viewMode === 'grid' 
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-white' 
                      : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                  )}
                >
                  <Grid3X3 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={cn(
                    'p-2 transition-colors',
                    viewMode === 'list' 
                      ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-white' 
                      : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                  )}
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Active Filters */}
          {(selectedCategory || searchQuery) && (
            <div className="flex items-center gap-2 mt-4 flex-wrap">
              <span className="text-sm text-muted-foreground">Filter aktif:</span>
              {selectedCategory && (
                <Badge 
                  variant="secondary" 
                  className="cursor-pointer"
                  onClick={() => setSelectedCategory('')}
                >
                  {categories.find(c => c.slug === selectedCategory)?.name}
                  <X className="w-3 h-3 ml-1" />
                </Badge>
              )}
              {searchQuery && (
                <Badge 
                  variant="secondary" 
                  className="cursor-pointer"
                  onClick={() => setSearchQuery('')}
                >
                  Search: {searchQuery}
                  <X className="w-3 h-3 ml-1" />
                </Badge>
              )}
              <button
                onClick={clearFilters}
                className="text-sm text-cyan-400 hover:underline"
              >
                Hapus semua
              </button>
            </div>
          )}
        </div>

        <div className="flex gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="glass rounded-xl p-6 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Filter</h3>
                <SlidersHorizontal className="w-4 h-4 text-muted-foreground" />
              </div>

              {/* Categories */}
              <div className="mb-6">
                <h4 className="text-sm font-medium mb-3">Kategori</h4>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <label key={category.id} className="flex items-center gap-2 cursor-pointer hover:text-cyan-400 transition-colors">
                      <Checkbox
                        checked={selectedCategory === category.slug}
                        onCheckedChange={() => setSelectedCategory(
                          selectedCategory === category.slug ? '' : category.slug
                        )}
                      />
                      <span className="text-sm">{category.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div>
                <h4 className="text-sm font-medium mb-3">Rentang Harga</h4>
                <div className="space-y-2">
                  <Input
                    type="number"
                    placeholder="Min"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value) || 0, priceRange[1]])}
                    className="bg-white/5 border-cyan-500/20"
                  />
                  <Input
                    type="number"
                    placeholder="Max"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value) || 1000000])}
                    className="bg-white/5 border-cyan-500/20"
                  />
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            <div className="mb-4 flex items-center justify-between">
              <p className="text-muted-foreground">
                Menampilkan {filteredProducts.length} produk
              </p>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                  <Search className="w-12 h-12 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Tidak ada produk
                </h3>
                <p className="text-muted-foreground mb-6">
                  Coba ubah filter atau kata kunci pencarian
                </p>
                <Button onClick={clearFilters} variant="outline" className="border-cyan-500/30">
                  Hapus Filter
                </Button>
              </div>
            ) : (
              <div className={cn(
                viewMode === 'grid'
                  ? 'grid sm:grid-cols-2 xl:grid-cols-3 gap-6'
                  : 'space-y-4'
              )}>
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} viewMode={viewMode} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
