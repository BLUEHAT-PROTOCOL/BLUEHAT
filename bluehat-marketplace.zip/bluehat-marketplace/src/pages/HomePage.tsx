// Bluehat Store - Home Page

import { Link } from 'react-router-dom';
import { 
  ArrowRight, Zap, Shield, Clock, Star, 
  TrendingUp, Sparkles, Gift, ChevronLeft, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { useProductStore } from '@/store/useStore';
import Hero3D from '@/components/3d/Hero3D';
import ParticleBackground from '@/components/3d/ParticleBackground';
import FloatingCard from '@/components/3d/FloatingCard';

// Product Card Component
function ProductCard({ product, featured = false }: { product: ReturnType<typeof useProductStore.getState>['products'][0]; featured?: boolean }) {
  const getProductTypeBadge = (type: string) => {
    switch (type) {
      case 'apps_premium':
        return { label: 'AUTO ACCOUNT', className: 'badge-apps' };
      case 'redeem_code':
        return { label: 'INSTANT CODE', className: 'badge-redeem' };
      case 'digital_file':
        return { label: 'DIGITAL DOWNLOAD', className: 'badge-digital' };
      case 'membership':
        return { label: 'SUBSCRIPTION', className: 'badge-membership' };
      case 'license_key':
        return { label: 'LICENSE', className: 'badge-license' };
      default:
        return { label: 'PHYSICAL', className: 'bg-gray-500 text-white' };
    }
  };

  const badge = getProductTypeBadge(product.type);

  return (
    <Link to={`/product/${product.slug}`}>
      <Card className="group glass border-cyan-500/10 hover:border-cyan-500/30 transition-all duration-300 overflow-hidden">
        <div className="relative aspect-square overflow-hidden">
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            <Badge className={`${badge.className} text-xs`}>
              {badge.label}
            </Badge>
            {product.isNewArrival && (
              <Badge className="bg-green-500 text-white text-xs">NEW</Badge>
            )}
            {product.compareAtPrice && (
              <Badge className="bg-red-500 text-white text-xs">
                -{Math.round((1 - product.price / product.compareAtPrice) * 100)}%
              </Badge>
            )}
          </div>

          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B122F] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold text-foreground line-clamp-1 group-hover:text-cyan-400 transition-colors">
            {product.name}
          </h3>
          
          <p className="text-sm text-muted-foreground line-clamp-1 mt-1">
            {product.shortDescription}
          </p>

          <div className="flex items-center gap-1 mt-2">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm text-foreground">{product.rating}</span>
            <span className="text-sm text-muted-foreground">({product.reviewCount})</span>
          </div>

          <div className="flex items-center justify-between mt-3">
            <div>
              <p className="text-lg font-bold text-cyan-400">
                Rp {product.price.toLocaleString('id-ID')}
              </p>
              {product.compareAtPrice && (
                <p className="text-sm text-muted-foreground line-through">
                  Rp {product.compareAtPrice.toLocaleString('id-ID')}
                </p>
              )}
            </div>
            
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity transform translate-x-4 group-hover:translate-x-0">
              <ArrowRight className="w-5 h-5 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

// Category Card Component
function CategoryCard({ category }: { category: ReturnType<typeof useProductStore.getState>['categories'][0] }) {
  return (
    <Link to={`/products?category=${category.slug}`}>
      <FloatingCard intensity={8}>
        <div className="relative aspect-[4/3] rounded-2xl overflow-hidden glass border border-cyan-500/10 group hover:border-cyan-500/30 transition-all">
          <img
            src={category.image}
            alt={category.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B122F] via-[#0B122F]/50 to-transparent" />
          
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-lg font-semibold text-foreground group-hover:text-cyan-400 transition-colors">
              {category.name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-1">
              {category.description}
            </p>
          </div>
        </div>
      </FloatingCard>
    </Link>
  );
}

// Feature Card Component
function FeatureCard({ icon: Icon, title, description }: { icon: typeof Zap; title: string; description: string }) {
  return (
    <div className="p-6 rounded-2xl glass border border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
        <Icon className="w-7 h-7 text-cyan-400" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}

export default function HomePage() {
  const { featuredProducts, newArrivals, bestSellers, categories } = useProductStore();

  return (
    <div className="relative">
      <ParticleBackground />
      
      {/* Hero Section */}
      <Hero3D />

      {/* Features Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-400 border-cyan-500/30">
              Kenapa Memilih Kami
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Keunggulan <span className="text-gradient">Bluehat Store</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Kami berkomitmen memberikan pengalaman belanja digital terbaik dengan layanan berkualitas
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard
              icon={Zap}
              title="Instant Delivery"
              description="Produk digital dikirim otomatis setelah pembayaran dikonfirmasi"
            />
            <FeatureCard
              icon={Shield}
              title="Garansi 100%"
              description="Uang kembali jika produk tidak sesuai atau tidak berfungsi"
            />
            <FeatureCard
              icon={Clock}
              title="Support 24/7"
              description="Tim support kami siap membantu kapan saja Anda butuhkan"
            />
            <FeatureCard
              icon={Sparkles}
              title="Harga Terbaik"
              description="Harga kompetitif dengan kualitas produk terjamin"
            />
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <Badge className="mb-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-400 border-cyan-500/30">
                Kategori
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                Jelajahi <span className="text-gradient">Kategori</span>
              </h2>
            </div>
            <Link to="/products">
              <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.slice(0, 6).map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <Badge className="mb-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-400 border-cyan-500/30">
                <Star className="w-3 h-3 mr-1" />
                Featured
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                Produk <span className="text-gradient">Unggulan</span>
              </h2>
            </div>
            <Link to="/products">
              <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} featured />
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <Badge className="mb-4 bg-gradient-to-r from-orange-500/20 to-red-500/20 text-orange-400 border-orange-500/30">
                <TrendingUp className="w-3 h-3 mr-1" />
                Best Seller
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                Produk <span className="text-gradient">Terlaris</span>
              </h2>
            </div>
            <Link to="/products?sort=best_seller">
              <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <Badge className="mb-4 bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-400 border-green-500/30">
                <Gift className="w-3 h-3 mr-1" />
                New Arrival
              </Badge>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                Produk <span className="text-gradient">Terbaru</span>
              </h2>
            </div>
            <Link to="/products?sort=newest">
              <Button variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden">
            {/* Background */}
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-cyan-500" />
            <div 
              className="absolute inset-0 opacity-30"
              style={{
                backgroundImage: `radial-gradient(circle at 20% 50%, rgba(255,255,255,0.2) 0%, transparent 50%)`,
              }}
            />
            
            {/* Content */}
            <div className="relative px-8 py-16 md:px-16 md:py-20 text-center">
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
                Siap Untuk Memulai?
              </h2>
              <p className="text-lg text-white/80 mb-8 max-w-2xl mx-auto">
                Bergabung dengan 50,000+ pelanggan puas dan nikmati akses premium ke aplikasi favoritmu
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/products">
                  <Button 
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-white/90 px-8 h-14 text-lg"
                  >
                    Beli Sekarang
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/register">
                  <Button 
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white/10 px-8 h-14 text-lg"
                  >
                    Daftar Gratis
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
