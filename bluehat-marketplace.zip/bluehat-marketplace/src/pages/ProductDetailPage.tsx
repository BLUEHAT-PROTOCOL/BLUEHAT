// Bluehat Store - Product Detail Page

import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { 
  Star, Heart, Share2, ShoppingCart, Check, Shield, 
  Clock, Zap, Package, ChevronRight, Minus, Plus,
  Download, Key, CreditCard, User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { useProductStore, useCartStore, useWishlistStore } from '@/store/useStore';

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { getProductBySlug, products } = useProductStore();
  const { addToCart } = useCartStore();
  const { isInWishlist, toggleWishlist } = useWishlistStore();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const product = getProductBySlug(slug || '');

  if (!product) {
    return (
      <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Produk tidak ditemukan</h1>
          <Link to="/products">
            <Button>Kembali ke Produk</Button>
          </Link>
        </div>
      </div>
    );
  }

  const relatedProducts = products
    .filter(p => p.categoryId === product.categoryId && p.id !== product.id)
    .slice(0, 4);

  const getProductTypeBadge = (type: string) => {
    switch (type) {
      case 'apps_premium':
        return { label: 'AUTO ACCOUNT', className: 'badge-apps', icon: User };
      case 'redeem_code':
        return { label: 'INSTANT CODE', className: 'badge-redeem', icon: Key };
      case 'digital_file':
        return { label: 'DIGITAL DOWNLOAD', className: 'badge-digital', icon: Download };
      case 'membership':
        return { label: 'SUBSCRIPTION', className: 'badge-membership', icon: CreditCard };
      case 'license_key':
        return { label: 'LICENSE', className: 'badge-license', icon: Key };
      default:
        return { label: 'PHYSICAL', className: 'bg-gray-500 text-white', icon: Package };
    }
  };

  const badge = getProductTypeBadge(product.type);
  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast.success(`${product.name} ditambahkan ke keranjang`);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate('/checkout');
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product.name,
          text: product.shortDescription,
          url: window.location.href,
        });
      } catch {
        // User cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link disalin ke clipboard');
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link to="/" className="hover:text-cyan-400 transition-colors">Beranda</Link>
          <ChevronRight className="w-4 h-4" />
          <Link to="/products" className="hover:text-cyan-400 transition-colors">Produk</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Images */}
          <div>
            <div className="aspect-square rounded-2xl overflow-hidden glass border border-cyan-500/10 mb-4">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index 
                        ? 'border-cyan-400' 
                        : 'border-transparent hover:border-cyan-400/50'
                    }`}
                  >
                    <img
                      src={image}
                      alt={`${product.name} - ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div>
            {/* Badges */}
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge className={`${badge.className}`}>
                <badge.icon className="w-3 h-3 mr-1" />
                {badge.label}
              </Badge>
              {product.isNewArrival && (
                <Badge className="bg-green-500 text-white">NEW</Badge>
              )}
              {product.isBestSeller && (
                <Badge className="bg-orange-500 text-white">BEST SELLER</Badge>
              )}
              {product.compareAtPrice && (
                <Badge className="bg-red-500 text-white">
                  -{Math.round((1 - product.price / product.compareAtPrice) * 100)}%
                </Badge>
              )}
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-muted-foreground'
                    }`}
                  />
                ))}
              </div>
              <span className="text-foreground font-medium">{product.rating}</span>
              <span className="text-muted-foreground">({product.reviewCount} ulasan)</span>
              <span className="text-muted-foreground">|</span>
              <span className="text-muted-foreground">{product.salesCount} terjual</span>
            </div>

            {/* Price */}
            <div className="mb-6">
              <p className="text-4xl font-bold text-cyan-400">
                Rp {product.price.toLocaleString('id-ID')}
              </p>
              {product.compareAtPrice && (
                <p className="text-lg text-muted-foreground line-through mt-1">
                  Rp {product.compareAtPrice.toLocaleString('id-ID')}
                </p>
              )}
            </div>

            {/* Short Description */}
            <p className="text-muted-foreground mb-6">
              {product.shortDescription}
            </p>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-cyan-400" />
                <span className="text-sm text-foreground">Instant Delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-cyan-400" />
                <span className="text-sm text-foreground">Garansi 100%</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-cyan-400" />
                <span className="text-sm text-foreground">Support 24/7</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-cyan-400" />
                <span className="text-sm text-foreground">Produk Original</span>
              </div>
            </div>

            {/* Quantity */}
            {product.type === 'physical' && (
              <div className="flex items-center gap-4 mb-6">
                <span className="text-foreground font-medium">Jumlah:</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-medium">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                    className="w-10 h-10 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-sm text-muted-foreground">
                  Stok: {product.stock}
                </span>
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button
                size="lg"
                className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 h-14"
                onClick={handleAddToCart}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Tambah ke Keranjang
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="flex-1 border-cyan-500/30 hover:bg-cyan-500/10 h-14"
                onClick={handleBuyNow}
              >
                Beli Sekarang
              </Button>
            </div>

            {/* Secondary Actions */}
            <div className="flex gap-4">
              <button
                onClick={() => toggleWishlist(product)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  inWishlist
                    ? 'bg-red-500/20 text-red-400'
                    : 'bg-white/5 text-muted-foreground hover:bg-white/10'
                }`}
              >
                <Heart className={`w-5 h-5 ${inWishlist ? 'fill-current' : ''}`} />
                {inWishlist ? 'Dalam Wishlist' : 'Tambah ke Wishlist'}
              </button>
              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 text-muted-foreground hover:bg-white/10 transition-colors"
              >
                <Share2 className="w-5 h-5" />
                Bagikan
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="glass border border-cyan-500/20">
              <TabsTrigger value="description">Deskripsi</TabsTrigger>
              <TabsTrigger value="details">Detail Produk</TabsTrigger>
              <TabsTrigger value="reviews">Ulasan ({product.reviewCount})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <div className="glass rounded-xl p-6 border border-cyan-500/10">
                <h3 className="text-lg font-semibold mb-4">Deskripsi Produk</h3>
                <p className="text-muted-foreground whitespace-pre-line">
                  {product.description}
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="details" className="mt-6">
              <div className="glass rounded-xl p-6 border border-cyan-500/10">
                <h3 className="text-lg font-semibold mb-4">Detail Produk</h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="flex justify-between py-2 border-b border-cyan-500/10">
                    <span className="text-muted-foreground">SKU</span>
                    <span className="text-foreground">{product.sku}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-cyan-500/10">
                    <span className="text-muted-foreground">Kategori</span>
                    <span className="text-foreground">{product.category?.name}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-cyan-500/10">
                    <span className="text-muted-foreground">Tipe Produk</span>
                    <span className="text-foreground">{badge.label}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-cyan-500/10">
                    <span className="text-muted-foreground">Stok</span>
                    <span className="text-foreground">{product.stock}</span>
                  </div>
                  {product.weight > 0 && (
                    <div className="flex justify-between py-2 border-b border-cyan-500/10">
                      <span className="text-muted-foreground">Berat</span>
                      <span className="text-foreground">{product.weight}g</span>
                    </div>
                  )}
                  {product.autoDelivery && (
                    <div className="flex justify-between py-2 border-b border-cyan-500/10">
                      <span className="text-muted-foreground">Pengiriman</span>
                      <span className="text-foreground">Otomatis</span>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="glass rounded-xl p-6 border border-cyan-500/10">
                <h3 className="text-lg font-semibold mb-4">Ulasan Pelanggan</h3>
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Belum ada ulasan untuk produk ini</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Produk <span className="text-gradient">Terkait</span>
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <Link key={p.id} to={`/product/${p.slug}`}>
                  <div className="glass rounded-xl overflow-hidden border border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
                    <div className="aspect-square overflow-hidden">
                      <img
                        src={p.images[0]}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium text-foreground line-clamp-1 group-hover:text-cyan-400 transition-colors">
                        {p.name}
                      </h3>
                      <p className="text-cyan-400 font-semibold mt-1">
                        Rp {p.price.toLocaleString('id-ID')}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
