// Bluehat Store - Payment Confirmation Page

import { useState, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, Upload, Clock, Copy, Check, AlertCircle,
  Image as ImageIcon, X, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useOrderStore } from '@/store/useStore';
import { paymentMethods } from '@/data/mockData';

export default function PaymentConfirmPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { orders, updatePaymentStatus } = useOrderStore();
  const order = orders.find(o => o.id === orderId);

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [formData, setFormData] = useState({
    senderName: '',
    senderAccount: '',
    transferAmount: '',
    notes: '',
  });

  if (!order) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Pesanan tidak ditemukan</h1>
          <Link to="/user/orders">
            <Button>Lihat Pesanan Saya</Button>
          </Link>
        </div>
      </div>
    );
  }

  const paymentMethod = paymentMethods[order.paymentMethod];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Ukuran file maksimal 5MB');
        return;
      }
      if (!file.type.startsWith('image/')) {
        toast.error('Hanya file gambar yang diizinkan');
        return;
      }
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setPreviewUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} disalin`);
  };

  const handleSubmit = async () => {
    if (!selectedFile) {
      toast.error('Mohon upload bukti pembayaran');
      return;
    }
    if (!formData.senderName || !formData.transferAmount) {
      toast.error('Mohon lengkapi data transfer');
      return;
    }

    setIsUploading(true);

    // Simulate upload
    setTimeout(() => {
      updatePaymentStatus(order.id, 'waiting_confirmation');
      setIsUploading(false);
      toast.success('Bukti pembayaran berhasil diupload!');
      navigate(`/payment-status/${order.id}`);
    }, 2000);
  };

  // Calculate time remaining (24 hours from order creation)
  const orderDate = new Date(order.createdAt);
  const expiryDate = new Date(orderDate.getTime() + 24 * 60 * 60 * 1000);
  const now = new Date();
  const timeRemaining = expiryDate.getTime() - now.getTime();
  const hoursRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60)));
  const minutesRemaining = Math.max(0, Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)));

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <button
          onClick={() => navigate('/user/orders')}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Kembali
        </button>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Konfirmasi Pembayaran
          </h1>
          <p className="text-muted-foreground">
            Silakan lakukan pembayaran dan upload bukti transfer
          </p>
        </div>

        {/* Timer Alert */}
        <Card className="glass border-yellow-500/30 mb-6">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
              <Clock className="w-6 h-6 text-yellow-400" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-foreground">Batas Waktu Pembayaran</p>
              <p className="text-sm text-muted-foreground">
                Selesaikan pembayaran dalam{' '}
                <span className="text-yellow-400 font-semibold">
                  {hoursRemaining} jam {minutesRemaining} menit
                </span>
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Payment Instructions */}
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Instruksi Pembayaran
              </h2>

              <div className="space-y-6">
                {/* Order Info */}
                <div className="p-4 rounded-xl bg-white/5">
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Nomor Pesanan</span>
                    <span className="font-medium text-foreground">{order.orderNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Pembayaran</span>
                    <span className="text-xl font-bold text-cyan-400">
                      Rp {order.total.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>

                {/* Payment Details */}
                <div>
                  <p className="text-sm text-muted-foreground mb-3">
                    {paymentMethod.instructions}
                  </p>
                  
                  <div className="p-4 rounded-xl bg-white/5 border border-cyan-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm text-muted-foreground">Metode</span>
                      <span className="font-medium text-foreground">{paymentMethod.name}</span>
                    </div>
                    
                    {paymentMethod.accountNumber !== '-' && (
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm text-muted-foreground">Nomor Rekening</span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium text-foreground">
                            {paymentMethod.accountNumber}
                          </span>
                          <button
                            onClick={() => handleCopy(paymentMethod.accountNumber, 'Nomor rekening')}
                            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
                          >
                            <Copy className="w-4 h-4 text-cyan-400" />
                          </button>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Atas Nama</span>
                      <span className="font-medium text-foreground">{paymentMethod.accountName}</span>
                    </div>
                  </div>
                </div>

                {/* Steps */}
                <div className="space-y-3">
                  <p className="font-medium text-foreground">Langkah-langkah:</p>
                  <ol className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">1</span>
                      Transfer sesuai total pembayaran
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">2</span>
                      Screenshot atau foto bukti transfer
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">3</span>
                      Upload bukti pembayaran di form berikut
                    </li>
                    <li className="flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs flex-shrink-0">4</span>
                      Tunggu konfirmasi dari admin (1x24 jam)
                    </li>
                  </ol>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upload Form */}
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Upload Bukti Pembayaran
              </h2>

              <div className="space-y-4">
                {/* File Upload */}
                <div>
                  <Label className="mb-2 block">Bukti Transfer</Label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept="image/*"
                    className="hidden"
                  />
                  
                  {!previewUrl ? (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full p-8 rounded-xl border-2 border-dashed border-cyan-500/30 hover:border-cyan-500/50 bg-white/5 hover:bg-white/10 transition-all"
                    >
                      <div className="flex flex-col items-center">
                        <div className="w-16 h-16 rounded-full bg-cyan-500/20 flex items-center justify-center mb-4">
                          <Upload className="w-8 h-8 text-cyan-400" />
                        </div>
                        <p className="text-foreground font-medium mb-1">
                          Klik untuk upload
                        </p>
                        <p className="text-sm text-muted-foreground">
                          JPG, PNG (Max 5MB)
                        </p>
                      </div>
                    </button>
                  ) : (
                    <div className="relative rounded-xl overflow-hidden">
                      <img
                        src={previewUrl}
                        alt="Preview"
                        className="w-full h-48 object-cover"
                      />
                      <button
                        onClick={handleRemoveFile}
                        className="absolute top-2 right-2 w-8 h-8 rounded-full bg-red-500/80 hover:bg-red-500 flex items-center justify-center transition-colors"
                      >
                        <X className="w-4 h-4 text-white" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Transfer Details */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="senderName">Nama Pengirim</Label>
                    <Input
                      id="senderName"
                      value={formData.senderName}
                      onChange={(e) => setFormData({ ...formData, senderName: e.target.value })}
                      placeholder="Nama sesuai rekening"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="senderAccount">Nomor Rekening (Opsional)</Label>
                    <Input
                      id="senderAccount"
                      value={formData.senderAccount}
                      onChange={(e) => setFormData({ ...formData, senderAccount: e.target.value })}
                      placeholder="Nomor rekening pengirim"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="transferAmount">Jumlah Transfer</Label>
                    <Input
                      id="transferAmount"
                      type="number"
                      value={formData.transferAmount}
                      onChange={(e) => setFormData({ ...formData, transferAmount: e.target.value })}
                      placeholder={`Minimal Rp ${order.total.toLocaleString('id-ID')}`}
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="notes">Catatan (Opsional)</Label>
                    <Input
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Tambahkan catatan"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 h-12"
                  onClick={handleSubmit}
                  disabled={isUploading}
                >
                  {isUploading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                      Mengupload...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5 mr-2" />
                      Konfirmasi Pembayaran
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
