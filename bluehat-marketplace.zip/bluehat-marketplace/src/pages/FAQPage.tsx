// Bluehat Store - FAQ Page

import { useState } from 'react';
import { Search, ChevronDown, MessageCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const faqs = [
  {
    category: 'Umum',
    questions: [
      {
        q: 'Apa itu Bluehat Store?',
        a: 'Bluehat Store adalah marketplace digital terpercaya di Indonesia yang menyediakan berbagai produk digital seperti akun premium aplikasi, kode redeem, asset digital, dan lisensi software.',
      },
      {
        q: 'Apakah Bluehat Store aman?',
        a: 'Ya, Bluehat Store menggunakan sistem keamanan terbaik dengan enkripsi data dan transaksi. Kami juga memberikan garansi uang kembali 100% jika produk tidak sesuai.',
      },
      {
        q: 'Bagaimana cara membuat akun?',
        a: 'Anda dapat membuat akun dengan mengklik tombol "Daftar" di pojok kanan atas, lalu mengisi formulir pendaftaran dengan data yang valid.',
      },
    ],
  },
  {
    category: 'Pembelian',
    questions: [
      {
        q: 'Bagaimana cara membeli produk?',
        a: 'Pilih produk yang Anda inginkan, klik "Tambah ke Keranjang", lalu lanjutkan ke checkout. Pilih metode pembayaran dan ikuti instruksi pembayaran.',
      },
      {
        q: 'Metode pembayaran apa saja yang tersedia?',
        a: 'Kami menerima pembayaran via QRIS, DANA, GoPay, OVO, LinkAja, dan transfer bank (BCA, Mandiri, BNI, BRI).',
      },
      {
        q: 'Berapa lama proses pengiriman?',
        a: 'Untuk produk digital, pengiriman dilakukan secara otomatis dan instan setelah pembayaran dikonfirmasi. Maksimal 1x24 jam.',
      },
    ],
  },
  {
    category: 'Pembayaran',
    questions: [
      {
        q: 'Bagaimana cara mengkonfirmasi pembayaran?',
        a: 'Setelah melakukan transfer, Anda dapat mengupload bukti pembayaran di halaman "Konfirmasi Pembayaran" atau melalui menu "Pesanan Saya".',
      },
      {
        q: 'Berapa lama batas waktu pembayaran?',
        a: 'Batas waktu pembayaran adalah 24 jam dari waktu pemesanan. Jika melebihi batas waktu, pesanan akan dibatalkan otomatis.',
      },
      {
        q: 'Apakah ada biaya admin?',
        a: 'Biaya admin bervariasi tergantung metode pembayaran. E-wallet umumnya tanpa biaya admin, sedangkan transfer bank memiliki biaya Rp 4.000.',
      },
    ],
  },
  {
    category: 'Produk',
    questions: [
      {
        q: 'Apa itu produk digital?',
        a: 'Produk digital adalah produk yang tidak memiliki bentuk fisik dan dapat dikirim secara elektronik, seperti akun premium, kode redeem, dan file digital.',
      },
      {
        q: 'Bagaimana cara menerima produk digital?',
        a: 'Produk digital akan dikirim ke email Anda atau dapat diakses melalui halaman "Pesanan Saya" setelah pembayaran dikonfirmasi.',
      },
      {
        q: 'Apakah ada garansi?',
        a: 'Ya, semua produk di Bluehat Store memiliki garansi. Jika produk bermasalah, Anda dapat mengajukan klaim dalam waktu yang telah ditentukan.',
      },
    ],
  },
  {
    category: 'Akun',
    questions: [
      {
        q: 'Bagaimana cara mengubah password?',
        a: 'Anda dapat mengubah password melalui menu "Profil" > "Keamanan" > "Ubah Password".',
      },
      {
        q: 'Bagaimana cara melihat riwayat pesanan?',
        a: 'Riwayat pesanan dapat dilihat melalui menu "Pesanan Saya" di dashboard akun Anda.',
      },
      {
        q: 'Apakah saya bisa menghapus akun?',
        a: 'Untuk menghapus akun, silakan hubungi customer support kami melalui email atau live chat.',
      },
    ],
  },
];

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-cyan-500/10 last:border-0">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between py-4 text-left"
      >
        <span className="font-medium text-foreground pr-4">{question}</span>
        <ChevronDown 
          className={cn(
            "w-5 h-5 text-cyan-400 flex-shrink-0 transition-transform",
            isOpen && "rotate-180"
          )} 
        />
      </button>
      {isOpen && (
        <div className="pb-4 text-muted-foreground">
          {answer}
        </div>
      )}
    </div>
  );
}

export default function FAQPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('Semua');

  const filteredFaqs = faqs.map(category => ({
    ...category,
    questions: category.questions.filter(
      q => 
        (activeCategory === 'Semua' || category.category === activeCategory) &&
        (q.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
         q.a.toLowerCase().includes(searchQuery.toLowerCase()))
    ),
  })).filter(category => category.questions.length > 0);

  const categories = ['Semua', ...faqs.map(f => f.category)];

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Pertanyaan <span className="text-gradient">Umum</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Temukan jawaban untuk pertanyaan yang sering diajukan. 
            Jika tidak menemukan jawaban, silakan hubungi kami.
          </p>
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Cari pertanyaan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-cyan-500/20"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium transition-colors",
                activeCategory === category
                  ? "bg-gradient-to-r from-blue-500 to-cyan-400 text-white"
                  : "bg-white/5 text-muted-foreground hover:bg-white/10"
              )}
            >
              {category}
            </button>
          ))}
        </div>

        {/* FAQ List */}
        <div className="space-y-6">
          {filteredFaqs.map((category) => (
            <Card key={category.category} className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold text-foreground mb-4">
                  {category.category}
                </h2>
                <div className="divide-y divide-cyan-500/10">
                  {category.questions.map((q, index) => (
                    <FAQItem key={index} question={q.q} answer={q.a} />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredFaqs.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Tidak ada hasil untuk pencarian Anda</p>
          </div>
        )}

        {/* Contact CTA */}
        <Card className="glass border-cyan-500/10 mt-8">
          <CardContent className="p-6 text-center">
            <MessageCircle className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Masih Punya Pertanyaan?
            </h2>
            <p className="text-muted-foreground mb-4">
              Tim support kami siap membantu Anda 24/7
            </p>
            <a href="mailto:support@bluehat.store">
              <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Hubungi Kami
              </Button>
            </a>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
