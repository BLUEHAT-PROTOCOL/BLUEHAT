// Bluehat Store - About Page

import { Link } from 'react-router-dom';
import { 
  Shield, Zap, Clock, Heart, Target, Users,
  CheckCircle, ArrowRight, Star
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const values = [
  {
    icon: Shield,
    title: 'Keamanan',
    description: 'Kami menjaga keamanan data dan transaksi pelanggan dengan sistem enkripsi terbaik.',
  },
  {
    icon: Zap,
    title: 'Kecepatan',
    description: 'Pengiriman produk digital secara instan setelah pembayaran dikonfirmasi.',
  },
  {
    icon: Heart,
    title: 'Kepuasan',
    description: 'Kepuasan pelanggan adalah prioritas utama kami dengan garansi uang kembali.',
  },
  {
    icon: Target,
    title: 'Kualitas',
    description: 'Hanya menyediakan produk berkualitas dari sumber terpercaya.',
  },
];

const stats = [
  { value: '50K+', label: 'Pelanggan Puas' },
  { value: '100+', label: 'Produk Tersedia' },
  { value: '99%', label: 'Tingkat Kepuasan' },
  { value: '24/7', label: 'Dukungan Pelanggan' },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-6">
            Tentang <span className="text-gradient">Bluehat Store</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Bluehat Store adalah marketplace digital terpercaya di Indonesia yang menyediakan 
            berbagai produk digital berkualitas dengan harga terbaik dan pelayanan prima.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="glass border-cyan-500/10">
              <CardContent className="p-6 text-center">
                <p className="text-3xl sm:text-4xl font-bold text-gradient mb-2">
                  {stat.value}
                </p>
                <p className="text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Story */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Cerita Kami
            </h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Bluehat Store didirikan pada tahun 2020 dengan visi untuk menjadi marketplace 
                digital terdepan di Indonesia. Kami memulai perjalanan dengan menyediakan 
                akun premium untuk aplikasi streaming populer.
              </p>
              <p>
                Seiring berkembangnya zaman, kami terus memperluas layanan untuk memenuhi 
                kebutuhan digital masyarakat Indonesia. Saat ini, kami menyediakan berbagai 
                produk digital mulai dari aplikasi premium, kode redeem, asset digital, 
                hingga lisensi software.
              </p>
              <p>
                Dengan dukungan tim yang berpengalaman dan sistem yang handal, kami berkomitmen 
                untuk terus memberikan pelayanan terbaik kepada setiap pelanggan.
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-video rounded-2xl overflow-hidden glass border border-cyan-500/20">
              <img
                src="https://images.unsplash.com/photo-1553877522-43269d4ea984?w=800"
                alt="Bluehat Store Team"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-foreground text-center mb-8">
            Nilai-Nilai Kami
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="glass border-cyan-500/10">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mb-4">
                    <value.icon className="w-6 h-6 text-cyan-400" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            Siap Untuk Bergabung?
          </h2>
          <p className="text-muted-foreground mb-6">
            Jadilah bagian dari komunitas Bluehat Store dan nikmati berbagai keuntungan
          </p>
          <Link to="/products">
            <Button size="lg" className="bg-gradient-to-r from-blue-500 to-cyan-400">
              Mulai Belanja
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
