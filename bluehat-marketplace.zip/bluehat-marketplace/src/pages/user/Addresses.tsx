// Bluehat Store - User Addresses Page

import { useState } from 'react';
import { MapPin, Plus, Edit2, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';

interface Address {
  id: string;
  label: string;
  recipient: string;
  phone: string;
  address: string;
  city: string;
  isDefault: boolean;
}

const mockAddresses: Address[] = [
  {
    id: '1',
    label: 'Rumah',
    recipient: 'John Doe',
    phone: '081234567890',
    address: 'Jl. Mawar No. 123',
    city: 'Jakarta',
    isDefault: true,
  },
];

export default function UserAddresses() {
  const [addresses, setAddresses] = useState<Address[]>(mockAddresses);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);

  const handleDelete = (id: string) => {
    setAddresses(addresses.filter(a => a.id !== id));
    toast.success('Alamat berhasil dihapus');
  };

  const handleSetDefault = (id: string) => {
    setAddresses(addresses.map(a => ({ ...a, isDefault: a.id === id })));
    toast.success('Alamat utama berhasil diubah');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Alamat Saya</h1>
          <p className="text-muted-foreground">Kelola alamat pengiriman Anda</p>
        </div>
        <Button 
          className="bg-gradient-to-r from-blue-500 to-cyan-400"
          onClick={() => {
            setEditingAddress(null);
            setIsDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Tambah Alamat
        </Button>
      </div>

      <div className="space-y-4">
        {addresses.map((address) => (
          <Card key={address.id} className="glass border-cyan-500/10">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{address.label}</span>
                      {address.isDefault && (
                        <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                          Utama
                        </span>
                      )}
                    </div>
                    <p className="text-foreground">{address.recipient}</p>
                    <p className="text-sm text-muted-foreground">{address.phone}</p>
                    <p className="text-sm text-muted-foreground">{address.address}</p>
                    <p className="text-sm text-muted-foreground">{address.city}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {!address.isDefault && (
                    <button
                      onClick={() => handleSetDefault(address.id)}
                      className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground"
                      title="Jadikan utama"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setEditingAddress(address);
                      setIsDialogOpen(true);
                    }}
                    className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(address.id)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {addresses.length === 0 && (
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-12 text-center">
              <MapPin className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Belum ada alamat tersimpan</p>
            </CardContent>
          </Card>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="glass-strong border-cyan-500/20">
          <DialogHeader>
            <DialogTitle>{editingAddress ? 'Edit Alamat' : 'Tambah Alamat'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div>
              <Label>Label</Label>
              <Input placeholder="Rumah, Kantor, dll" className="bg-white/5 border-cyan-500/20" />
            </div>
            <div>
              <Label>Nama Penerima</Label>
              <Input placeholder="Nama lengkap" className="bg-white/5 border-cyan-500/20" />
            </div>
            <div>
              <Label>Nomor Telepon</Label>
              <Input placeholder="081234567890" className="bg-white/5 border-cyan-500/20" />
            </div>
            <div>
              <Label>Alamat Lengkap</Label>
              <Input placeholder="Jl. ..." className="bg-white/5 border-cyan-500/20" />
            </div>
            <Button 
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-400"
              onClick={() => {
                toast.success(editingAddress ? 'Alamat diperbarui' : 'Alamat ditambahkan');
                setIsDialogOpen(false);
              }}
            >
              {editingAddress ? 'Simpan Perubahan' : 'Tambah Alamat'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
