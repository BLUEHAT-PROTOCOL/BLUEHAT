// Bluehat Store - User Notifications Page

import { Bell, Check, Trash2, ShoppingBag, CreditCard, Truck, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { useNotificationStore } from '@/store/useStore';

const iconMap: Record<string, typeof ShoppingBag> = {
  order: ShoppingBag,
  payment: CreditCard,
  shipment: Truck,
  promo: Gift,
  system: Bell,
};

export default function UserNotifications() {
  const { notifications, markAsRead, markAllAsRead, clearNotifications } = useNotificationStore();

  const handleMarkAsRead = (id: string) => {
    markAsRead(id);
  };

  const handleClearAll = () => {
    clearNotifications();
    toast.success('Semua notifikasi dihapus');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notifikasi</h1>
          <p className="text-muted-foreground">Kelola notifikasi Anda</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={markAllAsRead} className="border-cyan-500/30">
            <Check className="w-4 h-4 mr-2" />
            Tandai dibaca
          </Button>
          <Button variant="outline" size="sm" onClick={handleClearAll} className="border-red-500/30 hover:text-red-400">
            <Trash2 className="w-4 h-4 mr-2" />
            Hapus semua
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        {notifications.length === 0 ? (
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-12 text-center">
              <Bell className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Tidak ada notifikasi</p>
            </CardContent>
          </Card>
        ) : (
          notifications.map((notification) => {
            const Icon = iconMap[notification.type] || Bell;
            return (
              <Card 
                key={notification.id} 
                className={`glass border-cyan-500/10 ${!notification.isRead ? 'bg-cyan-500/5' : ''}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-cyan-400" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium text-foreground">{notification.title}</p>
                          <p className="text-sm text-muted-foreground">{notification.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(notification.createdAt).toLocaleDateString('id-ID')}
                          </p>
                        </div>
                        {!notification.isRead && (
                          <button
                            onClick={() => handleMarkAsRead(notification.id)}
                            className="w-2 h-2 rounded-full bg-cyan-400"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
