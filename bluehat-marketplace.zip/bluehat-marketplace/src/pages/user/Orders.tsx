// Bluehat Store - User Orders Page

import { Link } from 'react-router-dom';
import { 
  Package, Clock, CheckCircle, Truck, Search,
  ChevronRight, Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';
import { useOrderStore, useAuthStore } from '@/store/useStore';

const statusConfig = {
  pending: { label: 'Menunggu', color: 'bg-yellow-500/20 text-yellow-400', icon: Clock },
  waiting_confirmation: { label: 'Menunggu Konfirmasi', color: 'bg-blue-500/20 text-blue-400', icon: Clock },
  confirmed: { label: 'Dikonfirmasi', color: 'bg-blue-500/20 text-blue-400', icon: CheckCircle },
  processing: { label: 'Diproses', color: 'bg-purple-500/20 text-purple-400', icon: Package },
  shipped: { label: 'Dikirim', color: 'bg-cyan-500/20 text-cyan-400', icon: Truck },
  delivered: { label: 'Selesai', color: 'bg-green-500/20 text-green-400', icon: CheckCircle },
  cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400', icon: Clock },
};

export default function UserOrders() {
  const { user } = useAuthStore();
  const { orders } = useOrderStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const userOrders = orders.filter(o => o.userId === user?.id);

  const filteredOrders = userOrders.filter(order => {
    const matchesSearch = order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Pesanan Saya</h1>
        <p className="text-muted-foreground">Kelola dan lacak pesanan Anda</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Cari nomor pesanan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-cyan-500/20"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground"
        >
          <option value="all">Semua Status</option>
          <option value="pending">Menunggu</option>
          <option value="processing">Diproses</option>
          <option value="shipped">Dikirim</option>
          <option value="delivered">Selesai</option>
        </select>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-12 text-center">
              <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Belum ada pesanan
              </h3>
              <p className="text-muted-foreground mb-4">
                Anda belum memiliki pesanan. Yuk, mulai berbelanja!
              </p>
              <Link to="/products">
                <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
                  Lihat Produk
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          filteredOrders.map((order) => {
            const status = statusConfig[order.status as keyof typeof statusConfig] || statusConfig.pending;
            const StatusIcon = status.icon;

            return (
              <Card key={order.id} className="glass border-cyan-500/10">
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                        <StatusIcon className="w-7 h-7 text-cyan-400" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-foreground">{order.orderNumber}</p>
                          <Badge className={status.color}>
                            {status.label}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {new Date(order.createdAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                          })}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {order.items.length} item • Rp {order.total.toLocaleString('id-ID')}
                        </p>
                      </div>
                    </div>

                    <Link to={`/user/orders/${order.id}`}>
                      <Button variant="outline" className="border-cyan-500/30">
                        Detail
                        <ChevronRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
