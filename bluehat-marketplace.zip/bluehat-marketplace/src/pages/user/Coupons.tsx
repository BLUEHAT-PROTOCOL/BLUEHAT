// Bluehat Store - User Coupons Page

import { Ticket, Copy, Check, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useState } from 'react';
import { coupons } from '@/data/mockData';

export default function UserCoupons() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    toast.success('Kode kupon disalin');
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Kupon Saya</h1>
        <p className="text-muted-foreground">Kupon dan voucher yang tersedia</p>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {coupons.map((coupon) => (
          <Card key={coupon.id} className="glass border-cyan-500/10 overflow-hidden">
            <CardContent className="p-0">
              <div className="flex">
                {/* Left side - gradient */}
                <div className="w-20 bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center flex-shrink-0">
                  <Ticket className="w-8 h-8 text-white" />
                </div>
                
                {/* Right side - content */}
                <div className="flex-1 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-2xl font-bold text-cyan-400">
                        {coupon.type === 'percentage' ? `${coupon.value}%` : `Rp ${coupon.value.toLocaleString('id-ID')}`}
                      </p>
                      <p className="text-sm text-muted-foreground">{coupon.description}</p>
                      {coupon.minOrderAmount && (
                        <p className="text-xs text-muted-foreground">
                          Min. pembelian Rp {coupon.minOrderAmount.toLocaleString('id-ID')}
                        </p>
                      )}
                    </div>
                    <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                      Aktif
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-cyan-500/10">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      Berlaku sampai {new Date(coupon.endDate).toLocaleDateString('id-ID')}
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-cyan-500/30"
                      onClick={() => handleCopy(coupon.code)}
                    >
                      {copiedCode === coupon.code ? (
                        <>
                          <Check className="w-4 h-4 mr-1" />
                          Tersalin
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-1" />
                          {coupon.code}
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {coupons.length === 0 && (
          <Card className="glass border-cyan-500/10 sm:col-span-2">
            <CardContent className="p-12 text-center">
              <Ticket className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Tidak ada kupon tersedia</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
