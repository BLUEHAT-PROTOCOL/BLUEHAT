// Bluehat Store - User Wishlist Page

import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, Trash2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { useWishlistStore, useCartStore } from '@/store/useStore';

export default function UserWishlist() {
  const { items, removeFromWishlist } = useWishlistStore();
  const { addToCart } = useCartStore();

  const handleAddToCart = (product: typeof items[0]['product']) => {
    addToCart(product, 1);
    toast.success('Produk ditambahkan ke keranjang');
  };

  const handleRemove = (productId: string, productName: string) => {
    removeFromWishlist(productId);
    toast.success(`${productName} dihapus dari wishlist`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Wishlist Saya</h1>
        <p className="text-muted-foreground">Produk yang Anda simpan</p>
      </div>

      {items.length === 0 ? (
        <Card className="glass border-cyan-500/10">
          <CardContent className="p-12 text-center">
            <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Wishlist Kosong
            </h3>
            <p className="text-muted-foreground mb-6">
              Anda belum menyimpan produk apapun
            </p>
            <Link to="/products">
              <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Lihat Produk
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {items.map((item) => (
            <Card key={item.id} className="glass border-cyan-500/10">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <Link to={`/product/${item.product.slug}`}>
                    <div className="w-24 h-24 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/product/${item.product.slug}`}>
                      <p className="font-medium text-foreground hover:text-cyan-400 transition-colors line-clamp-1">
                        {item.product.name}
                      </p>
                    </Link>
                    <p className="text-lg font-bold text-cyan-400 mt-1">
                      Rp {item.product.price.toLocaleString('id-ID')}
                    </p>
                    <div className="flex gap-2 mt-3">
                      <Button
                        size="sm"
                        className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-400"
                        onClick={() => handleAddToCart(item.product)}
                      >
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        Beli
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-500/30 hover:bg-red-500/10 hover:text-red-400"
                        onClick={() => handleRemove(item.productId, item.product.name)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
