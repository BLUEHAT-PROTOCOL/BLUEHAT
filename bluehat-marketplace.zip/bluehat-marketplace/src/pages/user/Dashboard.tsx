// Bluehat Store - User Dashboard

import { Link } from 'react-router-dom';
import { 
  ShoppingBag, Heart, Ticket, Bell, Wallet,
  Package, Clock, CheckCircle, ArrowRight, Star
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuthStore, useOrderStore, useWishlistStore } from '@/store/useStore';

export default function UserDashboard() {
  const { user } = useAuthStore();
  const { orders } = useOrderStore();
  const { items: wishlistItems } = useWishlistStore();

  const userOrders = orders.filter(o => o.userId === user?.id);
  const pendingOrders = userOrders.filter(o => o.status === 'pending');
  const completedOrders = userOrders.filter(o => o.status === 'delivered');

  const stats = [
    { 
      icon: ShoppingBag, 
      label: 'Total Pesanan', 
      value: userOrders.length,
      color: 'from-blue-500 to-cyan-400',
      href: '/user/orders'
    },
    { 
      icon: Clock, 
      label: 'Menunggu', 
      value: pendingOrders.length,
      color: 'from-yellow-500 to-orange-400',
      href: '/user/orders'
    },
    { 
      icon: CheckCircle, 
      label: 'Selesai', 
      value: completedOrders.length,
      color: 'from-green-500 to-emerald-400',
      href: '/user/orders'
    },
    { 
      icon: Heart, 
      label: 'Wishlist', 
      value: wishlistItems.length,
      color: 'from-pink-500 to-rose-400',
      href: '/user/wishlist'
    },
  ];

  const recentOrders = userOrders.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Selamat Datang, {user?.name?.split(' ')[0]}!
          </h1>
          <p className="text-muted-foreground">
            Kelola pesanan dan akun Anda di sini
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Poin Loyalty</p>
            <p className="font-bold text-cyan-400">{user?.loyaltyPoints} pts</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Link key={stat.label} to={stat.href}>
            <Card className="glass border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
              <CardContent className="p-4 flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Link to="/products">
          <Card className="glass border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <ShoppingBag className="w-5 h-5 text-blue-400" />
                </div>
                <span className="font-medium text-foreground">Belanja</span>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
            </CardContent>
          </Card>
        </Link>
        <Link to="/user/wishlist">
          <Card className="glass border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-pink-400" />
                </div>
                <span className="font-medium text-foreground">Wishlist</span>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
            </CardContent>
          </Card>
        </Link>
        <Link to="/user/coupons">
          <Card className="glass border-cyan-500/10 hover:border-cyan-500/30 transition-all group">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                  <Ticket className="w-5 h-5 text-yellow-400" />
                </div>
                <span className="font-medium text-foreground">Kupon</span>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-cyan-400 group-hover:translate-x-1 transition-all" />
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Recent Orders */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-foreground">Pesanan Terakhir</h2>
            <Link to="/user/orders">
              <Button variant="ghost" size="sm" className="text-cyan-400">
                Lihat Semua
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          {recentOrders.length === 0 ? (
            <div className="text-center py-8">
              <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Belum ada pesanan</p>
              <Link to="/products">
                <Button variant="outline" className="mt-4 border-cyan-500/30">
                  Mulai Belanja
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div 
                  key={order.id}
                  className="flex items-center justify-between p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                      <Package className="w-6 h-6 text-cyan-400" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{order.orderNumber}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(order.createdAt).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-cyan-400">
                      Rp {order.total.toLocaleString('id-ID')}
                    </p>
                    <Badge 
                      variant="secondary" 
                      className={
                        order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                        order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-blue-500/20 text-blue-400'
                      }
                    >
                      {order.status === 'delivered' ? 'Selesai' :
                       order.status === 'pending' ? 'Pending' :
                       order.status === 'processing' ? 'Diproses' :
                       order.status === 'shipped' ? 'Dikirim' : order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Membership Info */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
                <Star className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Membership</p>
                <p className="text-xl font-bold text-foreground">
                  {user?.membershipType === 'gold' ? 'Gold Member' : 
                   user?.membershipType === 'silver' ? 'Silver Member' : 
                   user?.membershipType === 'platinum' ? 'Platinum Member' : 'Free Member'}
                </p>
                <p className="text-sm text-cyan-400">
                  Nikmati diskon hingga 10% untuk setiap pembelian
                </p>
              </div>
            </div>
            <Link to="/user/coupons">
              <Button variant="outline" className="border-cyan-500/30">
                Lihat Benefit
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
