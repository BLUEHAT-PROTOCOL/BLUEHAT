// Bluehat Store - User Order Detail Page

import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, Package, Clock, CheckCircle, Truck, Download,
  Copy, MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useOrderStore } from '@/store/useStore';

const statusConfig = {
  pending: { label: 'Menunggu Pembayaran', color: 'bg-yellow-500/20 text-yellow-400', icon: Clock },
  waiting_confirmation: { label: 'Menunggu Konfirmasi', color: 'bg-blue-500/20 text-blue-400', icon: Clock },
  confirmed: { label: 'Pembayaran Dikonfirmasi', color: 'bg-blue-500/20 text-blue-400', icon: CheckCircle },
  processing: { label: 'Sedang Diproses', color: 'bg-purple-500/20 text-purple-400', icon: Package },
  shipped: { label: 'Dikirim', color: 'bg-cyan-500/20 text-cyan-400', icon: Truck },
  delivered: { label: 'Selesai', color: 'bg-green-500/20 text-green-400', icon: CheckCircle },
  cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400', icon: Clock },
};

const timelineSteps = [
  { status: 'pending', label: 'Pesanan Dibuat' },
  { status: 'confirmed', label: 'Pembayaran Dikonfirmasi' },
  { status: 'processing', label: 'Sedang Diproses' },
  { status: 'shipped', label: 'Dikirim' },
  { status: 'delivered', label: 'Selesai' },
];

export default function UserOrderDetail() {
  const { orderId } = useParams<{ orderId: string }>();
  const { orders } = useOrderStore();
  const order = orders.find(o => o.id === orderId);

  if (!order) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Pesanan tidak ditemukan</p>
        <Link to="/user/orders">
          <Button variant="outline" className="mt-4 border-cyan-500/30">
            Kembali
          </Button>
        </Link>
      </div>
    );
  }

  const status = statusConfig[order.status as keyof typeof statusConfig] || statusConfig.pending;
  const StatusIcon = status.icon;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Disalin ke clipboard');
  };

  const currentStepIndex = timelineSteps.findIndex(s => s.status === order.status);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link to="/user/orders">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Detail Pesanan</h1>
          <p className="text-muted-foreground">{order.orderNumber}</p>
        </div>
      </div>

      {/* Status */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <StatusIcon className="w-8 h-8 text-cyan-400" />
            </div>
            <div>
              <Badge className={status.color}>
                {status.label}
              </Badge>
              <p className="text-sm text-muted-foreground mt-1">
                {new Date(order.createdAt).toLocaleDateString('id-ID', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-6">
          <h3 className="font-semibold text-foreground mb-4">Status Pesanan</h3>
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-cyan-500/20" />
            <div className="space-y-6">
              {timelineSteps.map((step, index) => {
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;

                return (
                  <div key={step.status} className="flex items-center gap-4 relative">
                    <div 
                      className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                        isCompleted 
                          ? 'bg-gradient-to-r from-blue-500 to-cyan-400' 
                          : 'bg-white/10'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-white" />
                      ) : (
                        <div className="w-2 h-2 rounded-full bg-muted-foreground" />
                      )}
                    </div>
                    <span className={`${isCompleted ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {step.label}
                    </span>
                    {isCurrent && (
                      <Badge variant="secondary" className="ml-auto bg-cyan-500/20 text-cyan-400">
                        Saat ini
                      </Badge>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Items */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-6">
          <h3 className="font-semibold text-foreground mb-4">Item Pesanan</h3>
          <div className="space-y-4">
            {order.items.map((item) => (
              <div key={item.id} className="flex gap-4 p-4 rounded-xl bg-white/5">
                <div className="w-20 h-20 rounded-lg overflow-hidden bg-white/10 flex-shrink-0">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{item.product.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.quantity} x Rp {item.price.toLocaleString('id-ID')}
                  </p>
                  {item.deliveredContent && (
                    <div className="mt-2 flex items-center gap-2">
                      <code className="px-2 py-1 rounded bg-black/30 text-sm font-mono text-cyan-400">
                        {item.deliveredContent}
                      </code>
                      <button
                        onClick={() => handleCopy(item.deliveredContent || '')}
                        className="p-1.5 rounded-lg hover:bg-white/10"
                      >
                        <Copy className="w-4 h-4 text-muted-foreground" />
                      </button>
                    </div>
                  )}
                </div>
                <p className="font-medium text-cyan-400">
                  Rp {item.subtotal.toLocaleString('id-ID')}
                </p>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="mt-6 pt-6 border-t border-cyan-500/10 space-y-2">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>Rp {order.subtotal.toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Ongkir</span>
              <span>Rp {order.shippingCost.toLocaleString('id-ID')}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Diskon</span>
                <span>-Rp {order.discount.toLocaleString('id-ID')}</span>
              </div>
            )}
            <div className="flex justify-between text-lg font-semibold text-foreground pt-2 border-t border-cyan-500/10">
              <span>Total</span>
              <span className="text-cyan-400">Rp {order.total.toLocaleString('id-ID')}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-4">
        {order.paymentStatus === 'pending' && (
          <Link to={`/payment-confirm/${order.id}`} className="flex-1">
            <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-400">
              Bayar Sekarang
            </Button>
          </Link>
        )}
        <Link to="/contact" className="flex-1">
          <Button variant="outline" className="w-full border-cyan-500/30">
            <MessageCircle className="w-4 h-4 mr-2" />
            Hubungi Support
          </Button>
        </Link>
      </div>
    </div>
  );
}
