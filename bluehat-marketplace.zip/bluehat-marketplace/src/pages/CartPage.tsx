// Bluehat Store - Cart Page

import { Link, useNavigate } from 'react-router-dom';
import { 
  ShoppingCart, Trash2, Plus, Minus, ArrowRight, 
  Package, Shield, Clock, Gift
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { useCartStore, useAuthStore } from '@/store/useStore';

export default function CartPage() {
  const navigate = useNavigate();
  const { items, removeFromCart, updateQuantity, getCartTotal, clearCart } = useCartStore();
  const { isAuthenticated } = useAuthStore();

  const total = getCartTotal();
  const shippingCost = 0; // Free for digital products
  const finalTotal = total + shippingCost;

  const handleRemove = (itemId: string, productName: string) => {
    removeFromCart(itemId);
    toast.success(`${productName} dihapus dari keranjang`);
  };

  const handleClear = () => {
    clearCart();
    toast.success('Keranjang dikosongkan');
  };

  const handleCheckout = () => {
    if (!isAuthenticated) {
      toast.error('Silakan login terlebih dahulu');
      navigate('/login', { state: { from: '/checkout' } });
      return;
    }
    navigate('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-foreground mb-8">Keranjang Belanja</h1>
          
          <div className="glass rounded-2xl p-12 text-center border border-cyan-500/10">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="w-12 h-12 text-cyan-400" />
            </div>
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              Keranjang Kosong
            </h2>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Belum ada produk di keranjang. Yuk, mulai belanja dan temukan produk digital terbaik!
            </p>
            <Link to="/products">
              <Button size="lg" className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Lihat Produk
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-foreground mb-8">Keranjang Belanja</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <Card 
                key={item.id} 
                className="glass border-cyan-500/10 overflow-hidden"
              >
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    {/* Image */}
                    <Link to={`/product/${item.product.slug}`}>
                      <div className="w-24 h-24 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </Link>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <Link 
                            to={`/product/${item.product.slug}`}
                            className="font-semibold text-foreground hover:text-cyan-400 transition-colors line-clamp-1"
                          >
                            {item.product.name}
                          </Link>
                          <p className="text-sm text-muted-foreground mt-1">
                            {item.product.type === 'physical' ? 'Produk Fisik' : 'Produk Digital'}
                          </p>
                        </div>
                        <button
                          onClick={() => handleRemove(item.id, item.product.name)}
                          className="p-2 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>

                      <div className="flex items-center justify-between mt-4">
                        {/* Quantity */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-10 text-center font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Price */}
                        <div className="text-right">
                          <p className="font-semibold text-cyan-400">
                            Rp {(item.product.price * item.quantity).toLocaleString('id-ID')}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Rp {item.product.price.toLocaleString('id-ID')} / item
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Clear Cart Button */}
            <Button
              variant="ghost"
              onClick={handleClear}
              className="text-muted-foreground hover:text-red-400"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Kosongkan Keranjang
            </Button>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="glass border-cyan-500/10 sticky top-24">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Ringkasan Pesanan
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal ({items.reduce((acc, item) => acc + item.quantity, 0)} item)</span>
                    <span>Rp {total.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Ongkir</span>
                    <span className="text-green-400">Gratis</span>
                  </div>
                  
                  {/* Coupon Input */}
                  <div className="pt-4 border-t border-cyan-500/10">
                    <label className="text-sm text-muted-foreground mb-2 block">
                      Kode Kupon
                    </label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Masukkan kode"
                        className="bg-white/5 border-cyan-500/20"
                      />
                      <Button variant="outline" className="border-cyan-500/30">
                        Terapkan
                      </Button>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-cyan-500/10">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-semibold text-foreground">Total</span>
                      <span className="text-2xl font-bold text-gradient">
                        Rp {finalTotal.toLocaleString('id-ID')}
                      </span>
                    </div>
                  </div>
                </div>

                <Button
                  className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 h-14 text-lg"
                  onClick={handleCheckout}
                >
                  Lanjutkan ke Checkout
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>

                {/* Features */}
                <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-cyan-500/10">
                  <div className="text-center">
                    <Package className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                    <span className="text-xs text-muted-foreground">Instant</span>
                  </div>
                  <div className="text-center">
                    <Shield className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                    <span className="text-xs text-muted-foreground">Aman</span>
                  </div>
                  <div className="text-center">
                    <Clock className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
                    <span className="text-xs text-muted-foreground">24/7</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
