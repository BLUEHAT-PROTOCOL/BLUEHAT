// Bluehat Store - Order Success Page

import { Link, useParams } from 'react-router-dom';
import { CheckCircle, Package, Download, ArrowRight, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useOrderStore } from '@/store/useStore';

export default function OrderSuccessPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const { orders } = useOrderStore();
  const order = orders.find(o => o.id === orderId);

  return (
    <div className="min-h-screen pt-24 pb-16 flex items-center justify-center">
      <div className="w-full max-w-lg px-4">
        <Card className="glass border-cyan-500/10">
          <CardContent className="p-8 text-center">
            {/* Success Icon */}
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>

            <h1 className="text-2xl font-bold text-foreground mb-2">
              Pesanan Berhasil!
            </h1>
            <p className="text-muted-foreground mb-6">
              Terima kasih telah berbelanja di Bluehat Store
            </p>

            {/* Order Details */}
            <div className="bg-white/5 rounded-xl p-4 mb-6 text-left">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Nomor Pesanan</span>
                <span className="font-medium text-foreground">{order?.orderNumber || '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total</span>
                <span className="font-bold text-cyan-400">
                  Rp {order?.total.toLocaleString('id-ID') || '-'}
                </span>
              </div>
            </div>

            {/* Next Steps */}
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Pesanan Anda sedang diproses. Anda akan menerima email konfirmasi dengan detail pesanan.
              </p>
              
              <div className="flex flex-col gap-3">
                <Link to={`/user/orders/${orderId}`}>
                  <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-400">
                    <Package className="w-4 h-4 mr-2" />
                    Lacak Pesanan
                  </Button>
                </Link>
                
                <Link to="/products">
                  <Button variant="outline" className="w-full border-cyan-500/30">
                    <Home className="w-4 h-4 mr-2" />
                    Kembali Berbelanja
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
