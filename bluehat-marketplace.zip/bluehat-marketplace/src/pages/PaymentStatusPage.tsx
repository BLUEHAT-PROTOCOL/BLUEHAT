// Bluehat Store - Payment Status Page

import { useParams, Link } from 'react-router-dom';
import { 
  CheckCircle, Clock, XCircle, ArrowRight, Package,
  MessageCircle, Download, RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useOrderStore } from '@/store/useStore';

const statusConfig = {
  pending: {
    icon: Clock,
    title: 'Menunggu Pembayaran',
    description: 'Silakan lakukan pembayaran dan upload bukti transfer',
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/20',
    badge: 'badge-pending',
  },
  waiting_confirmation: {
    icon: Clock,
    title: 'Menunggu Konfirmasi',
    description: 'Bukti pembayaran telah diterima, menunggu verifikasi admin',
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/20',
    badge: 'badge-confirmed',
  },
  confirmed: {
    icon: CheckCircle,
    title: 'Pembayaran Dikonfirmasi',
    description: 'Pembayaran telah dikonfirmasi, pesanan sedang diproses',
    color: 'text-green-400',
    bgColor: 'bg-green-500/20',
    badge: 'badge-delivered',
  },
  rejected: {
    icon: XCircle,
    title: 'Pembayaran Ditolak',
    description: 'Bukti pembayaran tidak valid, silakan upload ulang',
    color: 'text-red-400',
    bgColor: 'bg-red-500/20',
    badge: 'badge-cancelled',
  },
};

export default function PaymentStatusPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const { orders } = useOrderStore();
  const order = orders.find(o => o.id === orderId);

  if (!order) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Pesanan tidak ditemukan</h1>
          <Link to="/user/orders">
            <Button>Lihat Pesanan Saya</Button>
          </Link>
        </div>
      </div>
    );
  }

  const status = statusConfig[order.paymentStatus] || statusConfig.pending;
  const StatusIcon = status.icon;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="glass border-cyan-500/10">
          <CardContent className="p-8 text-center">
            {/* Status Icon */}
            <div className={`w-24 h-24 rounded-full ${status.bgColor} flex items-center justify-center mx-auto mb-6`}>
              <StatusIcon className={`w-12 h-12 ${status.color}`} />
            </div>

            {/* Status Badge */}
            <Badge className={status.badge}>
              {order.paymentStatus === 'waiting_confirmation' ? 'Menunggu Konfirmasi' : 
               order.paymentStatus === 'confirmed' ? 'Terkonfirmasi' :
               order.paymentStatus === 'rejected' ? 'Ditolak' : 'Pending'}
            </Badge>

            {/* Title & Description */}
            <h1 className="text-2xl font-bold text-foreground mt-4 mb-2">
              {status.title}
            </h1>
            <p className="text-muted-foreground mb-8">
              {status.description}
            </p>

            {/* Order Details */}
            <div className="bg-white/5 rounded-xl p-6 mb-8">
              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <p className="text-sm text-muted-foreground">Nomor Pesanan</p>
                  <p className="font-medium text-foreground">{order.orderNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="font-medium text-cyan-400">
                    Rp {order.total.toLocaleString('id-ID')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Metode</p>
                  <p className="font-medium text-foreground">{order.paymentMethod.toUpperCase()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-medium text-foreground capitalize">
                    {order.status.replace('_', ' ')}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {order.paymentStatus === 'pending' && (
                <Link to={`/payment-confirm/${order.id}`}>
                  <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
                    Upload Bukti Pembayaran
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              )}
              
              {order.paymentStatus === 'rejected' && (
                <Link to={`/payment-confirm/${order.id}`}>
                  <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
                    Upload Ulang
                    <RefreshCw className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              )}

              <Link to={`/user/orders/${order.id}`}>
                <Button variant="outline" className="border-cyan-500/30">
                  <Package className="w-4 h-4 mr-2" />
                  Detail Pesanan
                </Button>
              </Link>

              <Link to="/contact">
                <Button variant="ghost">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Hubungi Support
                </Button>
              </Link>
            </div>

            {/* Note */}
            <p className="text-sm text-muted-foreground mt-8">
              Butuh bantuan? Hubungi kami di{' '}
              <a href="mailto:support@bluehat.store" className="text-cyan-400 hover:underline">
                support@bluehat.store
              </a>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
