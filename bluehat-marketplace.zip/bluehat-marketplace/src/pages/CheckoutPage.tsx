// Bluehat Store - Checkout Page

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, CreditCard, Building2, Wallet, QrCode,
  Check, Copy, ChevronRight, Shield, Clock, AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { useCartStore, useAuthStore, useOrderStore } from '@/store/useStore';
import { paymentMethods } from '@/data/mockData';
import type { PaymentMethod } from '@/types';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { items, getCartTotal, clearCart } = useCartStore();
  const { user } = useAuthStore();
  const { addOrder } = useOrderStore();

  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod>('qris');
  const [isProcessing, setIsProcessing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    notes: '',
  });

  const total = getCartTotal();
  const paymentMethod = paymentMethods[selectedPayment];
  const fee = paymentMethod.fee;
  const finalTotal = total + fee;

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Keranjang Kosong</h1>
          <p className="text-muted-foreground mb-6">Tambahkan produk ke keranjang terlebih dahulu</p>
          <Link to="/products">
            <Button>Lihat Produk</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} disalin`);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error('Mohon lengkapi data diri');
      return;
    }

    setIsProcessing(true);

    // Simulate order creation
    setTimeout(() => {
      const newOrder = {
        id: `order-${Date.now()}`,
        orderNumber: `BLH-${Date.now().toString().slice(-8)}`,
        userId: user?.id || 'guest',
        status: 'pending' as const,
        paymentStatus: 'pending' as const,
        paymentMethod: selectedPayment,
        items: items.map(item => ({
          id: `item-${Date.now()}-${item.id}`,
          orderId: `order-${Date.now()}`,
          productId: item.productId,
          product: item.product,
          quantity: item.quantity,
          price: item.product.price,
          variantData: item.variantData,
          subtotal: item.product.price * item.quantity,
          downloadCount: 0,
        })),
        subtotal: total,
        discount: 0,
        shippingCost: 0,
        tax: 0,
        total: finalTotal,
        notes: formData.notes,
        giftWrap: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        tags: [],
      };

      addOrder(newOrder);
      clearCart();
      setIsProcessing(false);
      
      toast.success('Pesanan berhasil dibuat!');
      navigate(`/payment-confirm/${newOrder.id}`);
    }, 1500);
  };

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case 'qris':
        return QrCode;
      case 'bca':
      case 'mandiri':
      case 'bni':
      case 'bri':
        return Building2;
      default:
        return Wallet;
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <button
          onClick={() => navigate('/cart')}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          Kembali ke Keranjang
        </button>

        <h1 className="text-3xl font-bold text-foreground mb-8">Checkout</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Contact Information */}
            <Card className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Informasi Kontak
                </h2>
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nama Lengkap</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Masukkan nama lengkap"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Masukkan email"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>
                  
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="phone">Nomor Telepon</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="Contoh: 081234567890"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>
                  
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="notes">Catatan (Opsional)</Label>
                    <Input
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      placeholder="Tambahkan catatan untuk pesanan"
                      className="bg-white/5 border-cyan-500/20"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Method */}
            <Card className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Metode Pembayaran
                </h2>

                <RadioGroup
                  value={selectedPayment}
                  onValueChange={(value) => setSelectedPayment(value as PaymentMethod)}
                  className="space-y-3"
                >
                  {/* E-Wallets */}
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground mb-2">E-Wallet</p>
                    {(['qris', 'dana', 'gopay', 'ovo', 'linkaja'] as PaymentMethod[]).map((method) => {
                      const pm = paymentMethods[method];
                      const Icon = getPaymentIcon(method);
                      return (
                        <label
                          key={method}
                          className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                            selectedPayment === method
                              ? 'border-cyan-400 bg-cyan-500/10'
                              : 'border-cyan-500/10 hover:border-cyan-500/30 bg-white/5'
                          }`}
                        >
                          <RadioGroupItem value={method} id={method} />
                          <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
                            <Icon className="w-6 h-6 text-cyan-400" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{pm.name}</p>
                            <p className="text-sm text-muted-foreground">{pm.description}</p>
                          </div>
                          {pm.fee > 0 && (
                            <span className="text-sm text-muted-foreground">
                              +Rp {pm.fee.toLocaleString('id-ID')}
                            </span>
                          )}
                        </label>
                      );
                    })}
                  </div>

                  {/* Bank Transfer */}
                  <div className="space-y-2 pt-4">
                    <p className="text-sm text-muted-foreground mb-2">Transfer Bank</p>
                    {(['bca', 'mandiri', 'bni', 'bri'] as PaymentMethod[]).map((method) => {
                      const pm = paymentMethods[method];
                      return (
                        <label
                          key={method}
                          className={`flex items-center gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                            selectedPayment === method
                              ? 'border-cyan-400 bg-cyan-500/10'
                              : 'border-cyan-500/10 hover:border-cyan-500/30 bg-white/5'
                          }`}
                        >
                          <RadioGroupItem value={method} id={method} />
                          <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
                            <Building2 className="w-6 h-6 text-cyan-400" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-foreground">{pm.name}</p>
                            <p className="text-sm text-muted-foreground">{pm.description}</p>
                          </div>
                          {pm.fee > 0 && (
                            <span className="text-sm text-muted-foreground">
                              +Rp {pm.fee.toLocaleString('id-ID')}
                            </span>
                          )}
                        </label>
                      );
                    })}
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="glass border-cyan-500/10 sticky top-24">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Ringkasan Pesanan
                </h2>

                {/* Items */}
                <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground line-clamp-1">
                          {item.product.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {item.quantity} x Rp {item.product.price.toLocaleString('id-ID')}
                        </p>
                      </div>
                      <p className="text-sm font-medium text-cyan-400">
                        Rp {(item.product.price * item.quantity).toLocaleString('id-ID')}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="space-y-3 pt-4 border-t border-cyan-500/10">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal</span>
                    <span>Rp {total.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Biaya Admin</span>
                    <span>Rp {fee.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t border-cyan-500/10">
                    <span className="text-lg font-semibold text-foreground">Total</span>
                    <span className="text-2xl font-bold text-gradient">
                      Rp {finalTotal.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  className="w-full mt-6 bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 h-14 text-lg"
                  onClick={handleSubmit}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                      Memproses...
                    </>
                  ) : (
                    <>
                      Buat Pesanan
                      <ChevronRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>

                {/* Security Note */}
                <div className="flex items-center justify-center gap-4 mt-6 pt-6 border-t border-cyan-500/10">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Shield className="w-4 h-4 text-cyan-400" />
                    Aman
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    24/7
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
