// Bluehat Store - Admin Order Detail Page

import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, Package, Truck, CheckCircle, XCircle,
  User, Calendar, CreditCard, MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useOrderStore } from '@/store/useStore';

const statusConfig: Record<string, { label: string; color: string }> = {
  pending: { label: 'Pending', color: 'bg-yellow-500/20 text-yellow-400' },
  confirmed: { label: 'Dikonfirmasi', color: 'bg-blue-500/20 text-blue-400' },
  processing: { label: 'Diproses', color: 'bg-purple-500/20 text-purple-400' },
  shipped: { label: 'Dikirim', color: 'bg-cyan-500/20 text-cyan-400' },
  delivered: { label: 'Selesai', color: 'bg-green-500/20 text-green-400' },
  cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400' },
};

export default function AdminOrderDetail() {
  const { orderId } = useParams<{ orderId: string }>();
  const { orders, updateOrderStatus } = useOrderStore();
  const order = orders.find(o => o.id === orderId);

  if (!order) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Pesanan tidak ditemukan</p>
        <Link to="/admin/orders">
          <Button variant="outline" className="mt-4 border-cyan-500/30">
            Kembali
          </Button>
        </Link>
      </div>
    );
  }

  const status = statusConfig[order.status] || statusConfig.pending;

  const handleUpdateStatus = (status: string) => {
    updateOrderStatus(order.id, status as any);
    toast.success(`Status pesanan diubah ke ${status}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link to="/admin/orders">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Detail Pesanan</h1>
          <p className="text-muted-foreground">{order.orderNumber}</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Status */}
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                    <Package className="w-7 h-7 text-cyan-400" />
                  </div>
                  <div>
                    <Badge className={status.color}>
                      {status.label}
                    </Badge>
                    <p className="text-sm text-muted-foreground mt-1">
                      {new Date(order.createdAt).toLocaleString('id-ID')}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={() => handleUpdateStatus('processing')}
                    disabled={order.status === 'processing'}
                  >
                    Proses
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleUpdateStatus('shipped')}
                    disabled={order.status === 'shipped'}
                    className="border-cyan-500/30"
                  >
                    <Truck className="w-4 h-4 mr-2" />
                    Kirim
                  </Button>
                  <Button 
                    size="sm" 
                    className="bg-green-500 hover:bg-green-600"
                    onClick={() => handleUpdateStatus('delivered')}
                    disabled={order.status === 'delivered'}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Selesai
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Items */}
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <h3 className="font-semibold text-foreground mb-4">Item Pesanan</h3>
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex gap-4 p-4 rounded-xl bg-white/5">
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-white/10 flex-shrink-0">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{item.product.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {item.quantity} x Rp {item.price.toLocaleString('id-ID')}
                      </p>
                    </div>
                    <p className="font-medium text-cyan-400">
                      Rp {item.subtotal.toLocaleString('id-ID')}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-cyan-500/10 space-y-2">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>Rp {order.subtotal.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Ongkir</span>
                  <span>Rp {order.shippingCost.toLocaleString('id-ID')}</span>
                </div>
                {order.discount > 0 && (
                  <div className="flex justify-between text-green-400">
                    <span>Diskon</span>
                    <span>-Rp {order.discount.toLocaleString('id-ID')}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-semibold text-foreground pt-2 border-t border-cyan-500/10">
                  <span>Total</span>
                  <span className="text-cyan-400">Rp {order.total.toLocaleString('id-ID')}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Customer Info */}
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <h3 className="font-semibold text-foreground mb-4">Informasi Pelanggan</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-cyan-400" />
                  <span className="text-foreground">{order.user?.name || 'Guest'}</span>
                </div>
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-cyan-400" />
                  <span className="text-foreground capitalize">{order.paymentMethod}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          {order.notes && (
            <Card className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <h3 className="font-semibold text-foreground mb-2">Catatan</h3>
                <p className="text-muted-foreground">{order.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
