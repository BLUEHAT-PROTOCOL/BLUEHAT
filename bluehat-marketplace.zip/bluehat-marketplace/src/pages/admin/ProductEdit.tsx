// Bluehat Store - Admin Product Edit Page

import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Save, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

export default function AdminProductEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEditing = !!id;

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    type: 'apps_premium',
    category: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success(isEditing ? 'Produk diperbarui' : 'Produk ditambahkan');
    navigate('/admin/products');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link to="/admin/products">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            {isEditing ? 'Edit Produk' : 'Tambah Produk'}
          </h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Info */}
          <Card className="glass border-cyan-500/10 lg:col-span-2">
            <CardContent className="p-6 space-y-4">
              <div>
                <Label>Nama Produk</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Masukkan nama produk"
                  className="bg-white/5 border-cyan-500/20"
                />
              </div>

              <div>
                <Label>Deskripsi</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Deskripsi produk"
                  rows={5}
                  className="bg-white/5 border-cyan-500/20 resize-none"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label>Harga</Label>
                  <Input
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="0"
                    className="bg-white/5 border-cyan-500/20"
                  />
                </div>
                <div>
                  <Label>Stok</Label>
                  <Input
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                    placeholder="0"
                    className="bg-white/5 border-cyan-500/20"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label>Tipe Produk</Label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground"
                  >
                    <option value="apps_premium">Apps Premium</option>
                    <option value="redeem_code">Kode Redeem</option>
                    <option value="digital_file">Digital Asset</option>
                    <option value="membership">Membership</option>
                    <option value="license_key">License Key</option>
                    <option value="physical">Fisik</option>
                  </select>
                </div>
                <div>
                  <Label>Kategori</Label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground"
                  >
                    <option value="">Pilih Kategori</option>
                    <option value="cat-1">Apps Premium</option>
                    <option value="cat-2">Kode Redeem</option>
                    <option value="cat-3">Digital Assets</option>
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Image Upload */}
            <Card className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <Label>Gambar Produk</Label>
                <div className="mt-2 aspect-square rounded-xl border-2 border-dashed border-cyan-500/30 flex flex-col items-center justify-center bg-white/5 hover:bg-white/10 transition-colors cursor-pointer">
                  <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">Upload gambar</p>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="glass border-cyan-500/10">
              <CardContent className="p-6 space-y-3">
                <Button type="submit" className="w-full bg-gradient-to-r from-blue-500 to-cyan-400">
                  <Save className="w-4 h-4 mr-2" />
                  {isEditing ? 'Simpan Perubahan' : 'Tambah Produk'}
                </Button>
                <Link to="/admin/products">
                  <Button variant="outline" className="w-full border-cyan-500/30">
                    Batal
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
