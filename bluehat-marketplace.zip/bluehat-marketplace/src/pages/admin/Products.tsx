// Bluehat Store - Admin Products Page

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, Search, Edit2, Trash2, Eye, Filter,
  Package, MoreHorizontal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { useProductStore } from '@/store/useStore';

const typeLabels: Record<string, string> = {
  apps_premium: 'Apps Premium',
  redeem_code: 'Kode Redeem',
  digital_file: 'Digital Asset',
  membership: 'Membership',
  license_key: 'License Key',
  physical: 'Fisik',
};

export default function AdminProducts() {
  const { products } = useProductStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'all' || product.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleDelete = (productId: string) => {
    toast.success('Produk berhasil dihapus');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Produk</h1>
          <p className="text-muted-foreground">Kelola produk toko Anda</p>
        </div>
        <Link to="/admin/products/add">
          <Button className="bg-gradient-to-r from-blue-500 to-cyan-400">
            <Plus className="w-4 h-4 mr-2" />
            Tambah Produk
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Cari produk..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-cyan-500/20"
          />
        </div>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground"
        >
          <option value="all">Semua Tipe</option>
          {Object.entries(typeLabels).map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
      </div>

      {/* Products Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="glass border-cyan-500/10">
            <CardContent className="p-4">
              <div className="aspect-square rounded-lg overflow-hidden bg-white/5 mb-4">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-medium text-foreground line-clamp-1">{product.name}</p>
                  <p className="text-sm text-muted-foreground">{product.sku}</p>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="p-2 rounded-lg hover:bg-white/10">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glass-strong border-cyan-500/20">
                    <DropdownMenuItem asChild>
                      <Link to={`/product/${product.slug}`}>
                        <Eye className="w-4 h-4 mr-2" />
                        Lihat
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link to={`/admin/products/edit/${product.id}`}>
                        <Edit2 className="w-4 h-4 mr-2" />
                        Edit
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-red-400"
                      onClick={() => handleDelete(product.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Hapus
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="flex items-center justify-between mt-3">
                <Badge variant="secondary" className="text-xs">
                  {typeLabels[product.type]}
                </Badge>
                <p className="font-semibold text-cyan-400">
                  Rp {product.price.toLocaleString('id-ID')}
                </p>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-cyan-500/10">
                <span className="text-sm text-muted-foreground">
                  Stok: {product.stock}
                </span>
                <span className={`text-sm ${product.isActive ? 'text-green-400' : 'text-red-400'}`}>
                  {product.isActive ? 'Aktif' : 'Nonaktif'}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <Card className="glass border-cyan-500/10">
          <CardContent className="p-12 text-center">
            <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Tidak ada produk ditemukan</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
