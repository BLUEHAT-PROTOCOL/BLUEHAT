// Bluehat Store - Admin Customers Page

import { useState } from 'react';
import { 
  Search, Users, Mail, Phone, ShoppingBag,
  Star, MoreHorizontal
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { currentUser } from '@/data/mockData';

const mockCustomers = [
  currentUser,
  {
    id: 'user-2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    phone: '+6289876543210',
    role: 'customer',
    createdAt: new Date('2024-01-15'),
    loyaltyPoints: 2500,
    membershipType: 'gold',
  },
  {
    id: 'user-3',
    name: 'Bob Johnson',
    email: 'bob@example.com',
    phone: '+6281234567899',
    role: 'customer',
    createdAt: new Date('2024-02-01'),
    loyaltyPoints: 500,
    membershipType: 'silver',
  },
];

export default function AdminCustomers() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCustomers = mockCustomers.filter(customer =>
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Pelanggan</h1>
        <p className="text-muted-foreground">Kelola data pelanggan</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Cari pelanggan..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-white/5 border-cyan-500/20"
        />
      </div>

      <Card className="glass border-cyan-500/10">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-cyan-500/10">
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Pelanggan</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Kontak</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Membership</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Poin</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Bergabung</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="border-b border-cyan-500/5 hover:bg-white/5">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                          <span className="text-white font-medium">
                            {customer.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{customer.name}</p>
                          <p className="text-sm text-muted-foreground">{customer.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Phone className="w-4 h-4" />
                        {customer.phone}
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <Badge 
                        variant="secondary"
                        className={
                          customer.membershipType === 'gold' ? 'bg-yellow-500/20 text-yellow-400' :
                          customer.membershipType === 'silver' ? 'bg-gray-400/20 text-gray-400' :
                          'bg-cyan-500/20 text-cyan-400'
                        }
                      >
                        {customer.membershipType === 'gold' ? 'Gold' :
                         customer.membershipType === 'silver' ? 'Silver' : 'Free'}
                      </Badge>
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-cyan-400 font-medium">
                        {customer.loyaltyPoints} pts
                      </span>
                    </td>
                    <td className="py-4 px-6 text-muted-foreground">
                      {new Date(customer.createdAt).toLocaleDateString('id-ID')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
