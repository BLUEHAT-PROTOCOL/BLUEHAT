// Bluehat Store - Admin Settings Page

import { useState } from 'react';
import { Store, CreditCard, Truck, Bell, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState('general');

  const handleSave = () => {
    toast.success('Pengaturan berhasil disimpan');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Pengaturan</h1>
        <p className="text-muted-foreground">Kelola pengaturan toko</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="glass border border-cyan-500/20">
          <TabsTrigger value="general">Umum</TabsTrigger>
          <TabsTrigger value="payment">Pembayaran</TabsTrigger>
          <TabsTrigger value="shipping">Pengiriman</TabsTrigger>
          <TabsTrigger value="notifications">Notifikasi</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="mt-6">
          <Card className="glass border-cyan-500/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5 text-cyan-400" />
                Informasi Toko
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Nama Toko</Label>
                <Input defaultValue="Bluehat Store" className="bg-white/5 border-cyan-500/20" />
              </div>
              <div>
                <Label>Email</Label>
                <Input defaultValue="support@bluehat.store" className="bg-white/5 border-cyan-500/20" />
              </div>
              <div>
                <Label>Telepon</Label>
                <Input defaultValue="+62 812-3456-7890" className="bg-white/5 border-cyan-500/20" />
              </div>
              <div>
                <Label>Alamat</Label>
                <Input defaultValue="Jakarta, Indonesia" className="bg-white/5 border-cyan-500/20" />
              </div>
              <Button onClick={handleSave} className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Simpan Perubahan
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="mt-6">
          <Card className="glass border-cyan-500/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-cyan-400" />
                Metode Pembayaran
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                <div>
                  <p className="font-medium text-foreground">QRIS</p>
                  <p className="text-sm text-muted-foreground">Aktif</p>
                </div>
                <div className="w-12 h-6 rounded-full bg-green-500 relative">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                <div>
                  <p className="font-medium text-foreground">Transfer Bank</p>
                  <p className="text-sm text-muted-foreground">Aktif</p>
                </div>
                <div className="w-12 h-6 rounded-full bg-green-500 relative">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                <div>
                  <p className="font-medium text-foreground">E-Wallet</p>
                  <p className="text-sm text-muted-foreground">Aktif</p>
                </div>
                <div className="w-12 h-6 rounded-full bg-green-500 relative">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
                </div>
              </div>
              <Button onClick={handleSave} className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Simpan Perubahan
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping" className="mt-6">
          <Card className="glass border-cyan-500/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-cyan-400" />
                Pengaturan Pengiriman
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Ongkir Default</Label>
                <Input type="number" defaultValue="0" className="bg-white/5 border-cyan-500/20" />
              </div>
              <div>
                <Label>Estimasi Pengiriman (hari)</Label>
                <Input type="number" defaultValue="1" className="bg-white/5 border-cyan-500/20" />
              </div>
              <Button onClick={handleSave} className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Simpan Perubahan
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <Card className="glass border-cyan-500/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-cyan-400" />
                Notifikasi
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                <div>
                  <p className="font-medium text-foreground">Email Notifikasi</p>
                  <p className="text-sm text-muted-foreground">Kirim email saat ada pesanan baru</p>
                </div>
                <div className="w-12 h-6 rounded-full bg-green-500 relative">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                <div>
                  <p className="font-medium text-foreground">Notifikasi Pembayaran</p>
                  <p className="text-sm text-muted-foreground">Kirim email saat pembayaran diterima</p>
                </div>
                <div className="w-12 h-6 rounded-full bg-green-500 relative">
                  <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
                </div>
              </div>
              <Button onClick={handleSave} className="bg-gradient-to-r from-blue-500 to-cyan-400">
                Simpan Perubahan
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
