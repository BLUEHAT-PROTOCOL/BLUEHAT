// Bluehat Store - Admin Dashboard

import { Link } from 'react-router-dom';
import { 
  ShoppingBag, Users, DollarSign, Package, TrendingUp, TrendingDown,
  ArrowRight, Clock, AlertCircle, CheckCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { dashboardStats, analyticsData } from '@/data/mockData';
import { useOrderStore } from '@/store/useStore';

// Simple chart component
function SimpleChart({ data }: { data: typeof analyticsData }) {
  const maxValue = Math.max(...data.map(d => d.sales));
  
  return (
    <div className="flex items-end gap-2 h-32">
      {data.map((item, index) => (
        <div key={index} className="flex-1 flex flex-col items-center gap-1">
          <div 
            className="w-full bg-gradient-to-t from-blue-500 to-cyan-400 rounded-t-sm transition-all hover:opacity-80"
            style={{ height: `${(item.sales / maxValue) * 100}%` }}
          />
          <span className="text-xs text-muted-foreground">
            {new Date(item.date).getDate()}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function AdminDashboard() {
  const { orders } = useOrderStore();
  
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const pendingPayments = orders.filter(o => o.paymentStatus === 'waiting_confirmation');

  const stats = [
    {
      title: 'Total Penjualan',
      value: `Rp ${dashboardStats.totalSales.toLocaleString('id-ID')}`,
      change: `+${dashboardStats.salesChange}%`,
      icon: DollarSign,
      trend: 'up',
      color: 'from-green-500 to-emerald-500',
    },
    {
      title: 'Total Pesanan',
      value: dashboardStats.totalOrders.toString(),
      change: `+${dashboardStats.ordersChange}%`,
      icon: ShoppingBag,
      trend: 'up',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Total Pelanggan',
      value: dashboardStats.totalCustomers.toString(),
      change: '+12%',
      icon: Users,
      trend: 'up',
      color: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Total Produk',
      value: dashboardStats.totalProducts.toString(),
      change: '+5%',
      icon: Package,
      trend: 'up',
      color: 'from-orange-500 to-yellow-500',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Selamat datang kembali, Admin</p>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title} className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {stat.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className={`text-sm ${stat.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                      {stat.change}
                    </span>
                    <span className="text-sm text-muted-foreground">vs bulan lalu</span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Alerts */}
      <div className="grid sm:grid-cols-2 gap-6">
        {pendingOrders.length > 0 && (
          <Card className="glass border-yellow-500/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">Pesanan Menunggu</p>
                <p className="text-sm text-muted-foreground">
                  {pendingOrders.length} pesanan menunggu pembayaran
                </p>
              </div>
              <Link to="/admin/orders">
                <Button variant="outline" size="sm" className="border-yellow-500/30">
                  Lihat
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {pendingPayments.length > 0 && (
          <Card className="glass border-blue-500/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">Konfirmasi Pembayaran</p>
                <p className="text-sm text-muted-foreground">
                  {pendingPayments.length} bukti pembayaran perlu dikonfirmasi
                </p>
              </div>
              <Link to="/admin/payments">
                <Button variant="outline" size="sm" className="border-blue-500/30">
                  Proses
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Charts & Recent Orders */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Sales Chart */}
        <Card className="glass border-cyan-500/10 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Grafik Penjualan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SimpleChart data={analyticsData} />
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="glass border-cyan-500/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Aksi Cepat
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Link to="/admin/products/add">
              <Button variant="outline" className="w-full justify-start border-cyan-500/30">
                <Package className="w-4 h-4 mr-2" />
                Tambah Produk
              </Button>
            </Link>
            <Link to="/admin/orders">
              <Button variant="outline" className="w-full justify-start border-cyan-500/30">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Kelola Pesanan
              </Button>
            </Link>
            <Link to="/admin/payments">
              <Button variant="outline" className="w-full justify-start border-cyan-500/30">
                <DollarSign className="w-4 h-4 mr-2" />
                Konfirmasi Pembayaran
              </Button>
            </Link>
            <Link to="/admin/coupons">
              <Button variant="outline" className="w-full justify-start border-cyan-500/30">
                <CheckCircle className="w-4 h-4 mr-2" />
                Kelola Kupon
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card className="glass border-cyan-500/10">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg font-semibold text-foreground">
            Pesanan Terbaru
          </CardTitle>
          <Link to="/admin/orders">
            <Button variant="ghost" size="sm" className="text-cyan-400">
              Lihat Semua
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-cyan-500/10">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Order ID</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Pelanggan</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Total</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Tanggal</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 5).map((order) => (
                  <tr key={order.id} className="border-b border-cyan-500/5 hover:bg-white/5">
                    <td className="py-3 px-4">
                      <Link to={`/admin/orders/${order.id}`} className="text-cyan-400 hover:underline">
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="py-3 px-4 text-foreground">{order.user?.name || 'Guest'}</td>
                    <td className="py-3 px-4 text-cyan-400">
                      Rp {order.total.toLocaleString('id-ID')}
                    </td>
                    <td className="py-3 px-4">
                      <Badge 
                        variant="secondary"
                        className={
                          order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                          order.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                          order.status === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-purple-500/20 text-purple-400'
                        }
                      >
                        {order.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-muted-foreground">
                      {new Date(order.createdAt).toLocaleDateString('id-ID')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
