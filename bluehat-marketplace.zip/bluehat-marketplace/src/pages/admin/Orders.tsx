// Bluehat Store - Admin Orders Page

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, Eye, Package, Filter, MoreHorizontal,
  CheckCircle, XCircle, Truck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { useOrderStore } from '@/store/useStore';

const statusConfig: Record<string, { label: string; color: string }> = {
  pending: { label: 'Pending', color: 'bg-yellow-500/20 text-yellow-400' },
  confirmed: { label: 'Dikonfirmasi', color: 'bg-blue-500/20 text-blue-400' },
  processing: { label: 'Diproses', color: 'bg-purple-500/20 text-purple-400' },
  shipped: { label: 'Dikirim', color: 'bg-cyan-500/20 text-cyan-400' },
  delivered: { label: 'Selesai', color: 'bg-green-500/20 text-green-400' },
  cancelled: { label: 'Dibatalkan', color: 'bg-red-500/20 text-red-400' },
};

export default function AdminOrders() {
  const { orders, updateOrderStatus } = useOrderStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.user?.name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleUpdateStatus = (orderId: string, status: string) => {
    updateOrderStatus(orderId, status as any);
    toast.success(`Status pesanan diubah ke ${status}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Pesanan</h1>
        <p className="text-muted-foreground">Kelola pesanan pelanggan</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Cari pesanan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-cyan-500/20"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground"
        >
          <option value="all">Semua Status</option>
          {Object.entries(statusConfig).map(([value, config]) => (
            <option key={value} value={value}>{config.label}</option>
          ))}
        </select>
      </div>

      {/* Orders Table */}
      <Card className="glass border-cyan-500/10">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-cyan-500/10">
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Order ID</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Pelanggan</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Total</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Status</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Tanggal</th>
                  <th className="text-left py-4 px-6 text-sm font-medium text-muted-foreground">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => {
                  const status = statusConfig[order.status] || statusConfig.pending;
                  return (
                    <tr key={order.id} className="border-b border-cyan-500/5 hover:bg-white/5">
                      <td className="py-4 px-6">
                        <Link to={`/admin/orders/${order.id}`} className="text-cyan-400 hover:underline">
                          {order.orderNumber}
                        </Link>
                      </td>
                      <td className="py-4 px-6 text-foreground">{order.user?.name || 'Guest'}</td>
                      <td className="py-4 px-6 text-cyan-400">
                        Rp {order.total.toLocaleString('id-ID')}
                      </td>
                      <td className="py-4 px-6">
                        <Badge className={status.color}>
                          {status.label}
                        </Badge>
                      </td>
                      <td className="py-4 px-6 text-muted-foreground">
                        {new Date(order.createdAt).toLocaleDateString('id-ID')}
                      </td>
                      <td className="py-4 px-6">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="p-2 rounded-lg hover:bg-white/10">
                              <MoreHorizontal className="w-4 h-4" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="glass-strong border-cyan-500/20">
                            <DropdownMenuItem asChild>
                              <Link to={`/admin/orders/${order.id}`}>
                                <Eye className="w-4 h-4 mr-2" />
                                Lihat Detail
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleUpdateStatus(order.id, 'processing')}>
                              <Package className="w-4 h-4 mr-2" />
                              Proses
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleUpdateStatus(order.id, 'shipped')}>
                              <Truck className="w-4 h-4 mr-2" />
                              Kirim
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleUpdateStatus(order.id, 'delivered')}>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Selesai
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {filteredOrders.length === 0 && (
        <Card className="glass border-cyan-500/10">
          <CardContent className="p-12 text-center">
            <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Tidak ada pesanan ditemukan</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
