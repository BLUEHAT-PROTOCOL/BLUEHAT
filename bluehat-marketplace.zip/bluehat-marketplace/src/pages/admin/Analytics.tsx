// Bluehat Store - Admin Analytics Page

import { TrendingUp, TrendingDown, DollarSign, ShoppingBag, Users, Package } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { dashboardStats, analyticsData } from '@/data/mockData';

function SimpleChart({ data, dataKey }: { data: typeof analyticsData; dataKey: keyof typeof analyticsData[0] }) {
  const values = data.map(d => d[dataKey] as number);
  const maxValue = Math.max(...values);
  
  return (
    <div className="flex items-end gap-2 h-32">
      {data.map((item, index) => (
        <div key={index} className="flex-1 flex flex-col items-center gap-1">
          <div 
            className="w-full bg-gradient-to-t from-blue-500 to-cyan-400 rounded-t-sm transition-all hover:opacity-80"
            style={{ height: `${((item[dataKey] as number) / maxValue) * 100}%` }}
          />
          <span className="text-xs text-muted-foreground">
            {new Date(item.date).getDate()}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function AdminAnalytics() {
  const stats = [
    {
      title: 'Total Penjualan',
      value: `Rp ${dashboardStats.totalSales.toLocaleString('id-ID')}`,
      change: `+${dashboardStats.salesChange}%`,
      icon: DollarSign,
      trend: 'up',
    },
    {
      title: 'Total Pesanan',
      value: dashboardStats.totalOrders.toString(),
      change: `+${dashboardStats.ordersChange}%`,
      icon: ShoppingBag,
      trend: 'up',
    },
    {
      title: 'Rata-rata Order',
      value: `Rp ${Math.round(dashboardStats.totalSales / dashboardStats.totalOrders).toLocaleString('id-ID')}`,
      change: '+5%',
      icon: Package,
      trend: 'up',
    },
    {
      title: 'Konversi',
      value: '8.5%',
      change: '+1.2%',
      icon: Users,
      trend: 'up',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Analitik</h1>
        <p className="text-muted-foreground">Lihat performa toko Anda</p>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title} className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                  <div className="flex items-center gap-1 mt-2">
                    {stat.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 text-green-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className={`text-sm ${stat.trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-cyan-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="glass border-cyan-500/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Penjualan Harian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SimpleChart data={analyticsData} dataKey="sales" />
          </CardContent>
        </Card>

        <Card className="glass border-cyan-500/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Jumlah Pesanan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SimpleChart data={analyticsData} dataKey="orders" />
          </CardContent>
        </Card>

        <Card className="glass border-cyan-500/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Pengunjung
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SimpleChart data={analyticsData} dataKey="visitors" />
          </CardContent>
        </Card>

        <Card className="glass border-cyan-500/10">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">
              Nilai Order Rata-rata
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SimpleChart data={analyticsData} dataKey="averageOrderValue" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
