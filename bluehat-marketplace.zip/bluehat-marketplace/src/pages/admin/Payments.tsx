// Bluehat Store - Admin Payments Page

import { useState } from 'react';
import { 
  CheckCircle, XCircle, Eye, Search, Filter,
  Clock, Calendar, User, DollarSign, Image as ImageIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { useOrderStore } from '@/store/useStore';
import { paymentProofs } from '@/data/mockData';

export default function AdminPayments() {
  const { orders, updatePaymentStatus, updateOrderStatus } = useOrderStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProof, setSelectedProof] = useState<typeof paymentProofs[0] | null>(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'pending' | 'confirmed' | 'rejected'>('pending');

  const pendingPayments = orders.filter(o => o.paymentStatus === 'waiting_confirmation');
  const confirmedPayments = orders.filter(o => o.paymentStatus === 'confirmed');
  const rejectedPayments = orders.filter(o => o.paymentStatus === 'rejected');

  const handleConfirm = (orderId: string) => {
    updatePaymentStatus(orderId, 'confirmed');
    updateOrderStatus(orderId, 'processing');
    toast.success('Pembayaran berhasil dikonfirmasi');
  };

  const handleReject = (orderId: string) => {
    updatePaymentStatus(orderId, 'rejected');
    toast.error('Pembayaran ditolak');
  };

  const filteredOrders = (activeTab === 'pending' ? pendingPayments :
    activeTab === 'confirmed' ? confirmedPayments : rejectedPayments
  ).filter(order => 
    order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    order.user?.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Konfirmasi Pembayaran</h1>
          <p className="text-muted-foreground">Verifikasi dan konfirmasi bukti pembayaran pelanggan</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Card 
          className={`glass cursor-pointer transition-all ${activeTab === 'pending' ? 'border-cyan-400' : 'border-cyan-500/10'}`}
          onClick={() => setActiveTab('pending')}
        >
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-yellow-500/20 flex items-center justify-center">
              <Clock className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{pendingPayments.length}</p>
              <p className="text-sm text-muted-foreground">Menunggu</p>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`glass cursor-pointer transition-all ${activeTab === 'confirmed' ? 'border-cyan-400' : 'border-cyan-500/10'}`}
          onClick={() => setActiveTab('confirmed')}
        >
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{confirmedPayments.length}</p>
              <p className="text-sm text-muted-foreground">Terkonfirmasi</p>
            </div>
          </CardContent>
        </Card>

        <Card 
          className={`glass cursor-pointer transition-all ${activeTab === 'rejected' ? 'border-cyan-400' : 'border-cyan-500/10'}`}
          onClick={() => setActiveTab('rejected')}
        >
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
              <XCircle className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{rejectedPayments.length}</p>
              <p className="text-sm text-muted-foreground">Ditolak</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Cari berdasarkan nomor pesanan atau nama..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-white/5 border-cyan-500/20"
        />
      </div>

      {/* Payments List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <Card className="glass border-cyan-500/10">
            <CardContent className="p-12 text-center">
              <Clock className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Tidak ada pembayaran
              </h3>
              <p className="text-muted-foreground">
                {activeTab === 'pending' 
                  ? 'Tidak ada pembayaran yang menunggu konfirmasi'
                  : activeTab === 'confirmed'
                  ? 'Belum ada pembayaran yang dikonfirmasi'
                  : 'Belum ada pembayaran yang ditolak'}
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredOrders.map((order) => (
            <Card key={order.id} className="glass border-cyan-500/10">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Order Info */}
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-xl bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                      <DollarSign className="w-8 h-8 text-cyan-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-foreground">{order.orderNumber}</p>
                        <Badge 
                          variant="secondary"
                          className={
                            order.paymentStatus === 'confirmed' ? 'bg-green-500/20 text-green-400' :
                            order.paymentStatus === 'rejected' ? 'bg-red-500/20 text-red-400' :
                            'bg-yellow-500/20 text-yellow-400'
                          }
                        >
                          {order.paymentStatus === 'waiting_confirmation' ? 'Menunggu' :
                           order.paymentStatus === 'confirmed' ? 'Terkonfirmasi' : 'Ditolak'}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {order.user?.name || 'Guest'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(order.createdAt).toLocaleDateString('id-ID')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Amount */}
                  <div className="text-left lg:text-right">
                    <p className="text-2xl font-bold text-cyan-400">
                      Rp {order.total.toLocaleString('id-ID')}
                    </p>
                    <p className="text-sm text-muted-foreground capitalize">
                      {order.paymentMethod.replace('_', ' ')}
                    </p>
                  </div>

                  {/* Actions */}
                  {activeTab === 'pending' && (
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsViewOpen(true)}
                        className="border-cyan-500/30"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Lihat
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleConfirm(order.id)}
                        className="bg-green-500 hover:bg-green-600"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Konfirmasi
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleReject(order.id)}
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Tolak
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* View Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="max-w-lg glass-strong border-cyan-500/20">
          <DialogHeader>
            <DialogTitle>Detail Pembayaran</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="aspect-video rounded-xl bg-white/5 flex items-center justify-center">
              <ImageIcon className="w-16 h-16 text-muted-foreground" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Nama Pengirim</p>
                <p className="font-medium text-foreground">John Doe</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Jumlah Transfer</p>
                <p className="font-medium text-cyan-400">Rp 450.000</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Tanggal</p>
                <p className="font-medium text-foreground">25 Feb 2024</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Metode</p>
                <p className="font-medium text-foreground">BCA</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
