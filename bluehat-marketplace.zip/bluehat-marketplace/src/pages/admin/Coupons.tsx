// Bluehat Store - Admin Coupons Page

import { useState } from 'react';
import { Plus, Edit2, Trash2, Ticket, Percent, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { coupons } from '@/data/mockData';

export default function AdminCoupons() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<typeof coupons[0] | null>(null);

  const handleDelete = (id: string) => {
    toast.success('Kupon berhasil dihapus');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Kupon</h1>
          <p className="text-muted-foreground">Kelola kupon dan promo</p>
        </div>
        <Button 
          className="bg-gradient-to-r from-blue-500 to-cyan-400"
          onClick={() => {
            setEditingCoupon(null);
            setIsDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Tambah Kupon
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map((coupon) => (
          <Card key={coupon.id} className="glass border-cyan-500/10">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                  <Ticket className="w-6 h-6 text-white" />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setEditingCoupon(coupon);
                      setIsDialogOpen(true);
                    }}
                    className="p-2 rounded-lg hover:bg-white/10"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(coupon.id)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-3xl font-bold text-cyan-400">
                  {coupon.type === 'percentage' ? `${coupon.value}%` : `Rp ${coupon.value.toLocaleString('id-ID')}`}
                </p>
                <p className="text-sm text-muted-foreground">{coupon.description}</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Percent className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">Kode: </span>
                  <code className="px-2 py-0.5 rounded bg-white/10 text-cyan-400">
                    {coupon.code}
                  </code>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">
                    {new Date(coupon.startDate).toLocaleDateString('id-ID')} - {new Date(coupon.endDate).toLocaleDateString('id-ID')}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-cyan-500/10">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">
                    Digunakan: {coupon.usageCount}/{coupon.usageLimit || '∞'}
                  </span>
                  <Badge variant="secondary" className="bg-green-500/20 text-green-400">
                    Aktif
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="glass-strong border-cyan-500/20">
          <DialogHeader>
            <DialogTitle>{editingCoupon ? 'Edit Kupon' : 'Tambah Kupon'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div>
              <Label>Kode Kupon</Label>
              <Input placeholder="CONTOH10" className="bg-white/5 border-cyan-500/20" />
            </div>
            <div>
              <Label>Deskripsi</Label>
              <Input placeholder="Diskon 10%" className="bg-white/5 border-cyan-500/20" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Tipe</Label>
                <select className="w-full px-3 py-2 rounded-lg bg-white/5 border border-cyan-500/20 text-foreground">
                  <option value="percentage">Persentase</option>
                  <option value="fixed">Nominal</option>
                </select>
              </div>
              <div>
                <Label>Nilai</Label>
                <Input type="number" placeholder="10" className="bg-white/5 border-cyan-500/20" />
              </div>
            </div>
            <Button 
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-400"
              onClick={() => {
                toast.success(editingCoupon ? 'Kupon diperbarui' : 'Kupon ditambahkan');
                setIsDialogOpen(false);
              }}
            >
              {editingCoupon ? 'Simpan Perubahan' : 'Tambah Kupon'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
